---
name: apple
description: "Apple ecosystem: Notes, Reminders, Find My, iMessage, macOS computer use."
version: 1.0.0
author: Hermes Agent (consolidated)
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [Apple, macOS, Notes, Reminders, Find-My, iMessage, Computer-Use]
    related_skills: [apple-notes, apple-reminders, findmy, imessage, macos-computer-use]
---

# Apple Ecosystem

Apple-specific integrations: Notes, Reminders, Find My, iMessage, and macOS computer use.

## Skill Map

| Skill | Description |
|-------|-------------|
| Apple Notes | Read, search, create, edit notes via `memo` CLI |
| Apple Reminders | Manage reminders via `remindctl` CLI |
| Find My | Locate Apple devices via Find My network |
| iMessage | Send/receive iMessages via BlueBubbles |
| macOS Computer Use | Screen interaction, app control on macOS |

## Quick Reference: Apple Notes
```bash
memo list                    # List notes
memo search "query"          # Search notes
memo show <id>               # Show note content
memo create "Title" "Body"   # Create note
```

## Quick Reference: Apple Reminders
```bash
remindctl list               # List reminders
remindctl add "Title"        # Add reminder
remindctl complete <id>      # Mark complete
```

## Quick Reference: iMessage (BlueBubbles)
Requires BlueBubbles server running on macOS.
