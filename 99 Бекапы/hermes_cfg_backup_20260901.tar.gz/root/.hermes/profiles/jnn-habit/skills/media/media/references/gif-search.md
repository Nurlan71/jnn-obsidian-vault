# GIF Search — Condensed Reference

## Setup
- Get free API key: https://developers.google.com/tenor/guides/quickstart
- Set `TENOR_API_KEY` in `~/.hermes/.env`

## Search & Download
```bash
# Search
curl -s "https://tenor.googleapis.com/v2/search?q=thumbs+up&limit=5&key=${TENOR_API_KEY}" \
  | jq -r '.results[].media_formats.gif.url'

# Download
URL=$(curl -s "https://tenor.googleapis.com/v2/search?q=celebration&limit=1&key=${TENOR_API_KEY}" \
  | jq -r '.results[0].media_formats.gif.url')
curl -sL "$URL" -o celebration.gif
```

## Media Formats
| Format | Use |
|--------|-----|
| `gif` | Full quality |
| `tinygif` | Small preview (lighter for chat) |
| `mp4` | Video version |
| `nanogif` | Tiny thumbnail |
