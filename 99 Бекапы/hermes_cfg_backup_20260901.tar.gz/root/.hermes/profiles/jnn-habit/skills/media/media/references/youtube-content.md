# YouTube Content — Condensed Reference

Extract transcripts and convert to structured content.

## Install
```bash
pip install youtube-transcript-api
```

## Fetch Transcript
```bash
python3 scripts/fetch_transcript.py "https://youtube.com/watch?v=VIDEO_ID"
python3 scripts/fetch_transcript.py "URL" --text-only
python3 scripts/fetch_transcript.py "URL" --timestamps
python3 scripts/fetch_transcript.py "URL" --language tr,en
```

## Output Formats
- **Chapters**: Timestamped topic shifts
- **Summary**: 5-10 sentence overview
- **Thread**: Twitter/X thread (numbered, <280 chars each)
- **Blog post**: Full article with title, sections, key takeaways
- **Quotes**: Notable quotes with timestamps

## Error Handling
- Transcript disabled → tell user
- Private/unavailable → verify URL
- No matching language → retry without `--language`
