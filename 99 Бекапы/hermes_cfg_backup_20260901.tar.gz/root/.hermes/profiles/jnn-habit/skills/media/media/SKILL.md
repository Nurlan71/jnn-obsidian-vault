---
name: media
description: "Media content: GIF search, audio analysis, music generation, YouTube transcripts."
version: 1.0.0
author: Hermes Agent (consolidated)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Media, GIF, Audio, Music, YouTube, Spectrogram, Transcripts]
    related_skills: [gif-search, heartmula, songsee, youtube-content]
---

# Media Content

GIF search, audio analysis, music generation, and YouTube transcript extraction.

## Skill Map

| Topic | Tool | Reference |
|-------|------|-----------|
| GIF search/download | Tenor API via curl+jq | [references/gif-search.md](references/gif-search.md) |
| Music generation | HeartMuLa (open-source Suno alternative) | [references/heartmula.md](references/heartmula.md) |
| Audio analysis | songsee (spectrograms, mel, chroma, MFCC) | [references/songsee.md](references/songsee.md) |
| YouTube transcripts | youtube-transcript-api | [references/youtube-content.md](references/youtube-content.md) |

## Quick Reference: GIF Search
```bash
curl -s "https://tenor.googleapis.com/v2/search?q=thumbs+up&limit=5&key=${TENOR_API_KEY}" \
  | jq -r '.results[].media_formats.gif.url'
```

## Quick Reference: YouTube Transcripts
```bash
pip install youtube-transcript-api
python3 scripts/fetch_transcript.py "https://youtube.com/watch?v=VIDEO_ID" --text-only
# Output formats: chapters, summary, thread, blog post, quotes
```

## Quick Reference: Audio Analysis
```bash
go install github.com/steipete/songsee/cmd/songsee@latest
songsee track.mp3 --viz spectrogram,mel,chroma,mfcc
songsee track.mp3 --start 12.5 --duration 8 -o slice.jpg
```

## References
- `references/gif-search.md` — Tenor API search, download, metadata
- `references/heartmula.md` — HeartMuLa installation, generation, pitfalls
- `references/songsee.md` — Visualization types, flags, output formats
- `references/youtube-content.md` — Transcript fetching, output formats, error handling
