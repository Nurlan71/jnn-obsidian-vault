# songsee — Condensed Reference

Generate spectrograms and audio feature visualizations.

## Install
```bash
go install github.com/steipete/songsee/cmd/songsee@latest
```

## Usage
```bash
songsee track.mp3                                    # Basic spectrogram
songsee track.mp3 --viz spectrogram,mel,chroma,mfcc  # Multi-panel grid
songsee track.mp3 --start 12.5 --duration 8 -o slice.jpg
songsee track.mp3 --style magma                      # Color palette
```

## Visualization Types
`spectrogram`, `mel`, `chroma`, `hpss`, `selfsim`, `loudness`, `tempogram`, `mfcc`, `flux`
