# HeartMuLa — Condensed Reference

Open-source music generation from lyrics + tags (Apache-2.0).

## Hardware
- Minimum: 8GB VRAM with `--lazy_load true`
- Recommended: 16GB+ VRAM

## Installation
```bash
git clone https://github.com/HeartMuLa/heartlib.git && cd heartlib
uv venv --python 3.10 .venv && . .venv/bin/activate
uv pip install -e .
# Fix deps: uv pip install --upgrade datasets transformers
# Patch source: RoPE cache fix + HeartCodec loading fix (see full skill)
hf download --local-dir './ckpt' 'HeartMuLa/HeartMuLaGen'
```

## Usage
```bash
python ./examples/run_music_generation.py \
  --model_path=./ckpt --version="3B" \
  --lyrics="./assets/lyrics.txt" --tags="./assets/tags.txt" \
  --save_path="./output.mp3" --lazy_load true
```

## Input Format
- Tags: `piano,happy,wedding,synthesizer,romantic` (comma-separated, no spaces)
- Lyrics: Use `[Intro]`, `[Verse]`, `[Chorus]`, `[Bridge]`, `[Outro]` tags
- Output: MP3, 48kHz stereo, 128kbps

## Pitfalls
- Do NOT use bf16 for HeartCodec (use fp32)
- Tags may be ignored (known issue)
- Requires the dependency patches for transformers 5.x
