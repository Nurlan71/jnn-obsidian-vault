# Hermes Agent Self-Management — Condensed Reference

## CLI Quick Reference
```bash
hermes                        # Interactive chat
hermes chat -q "query"       # Single query
hermes setup                 # Interactive wizard
hermes model                 # Change model/provider
hermes config set KEY VAL    # Set config value
hermes doctor                # Health check
hermes skills list           # List skills
hermes cron list             # List cron jobs
hermes gateway status        # Gateway status
```

## Key Paths
- Config (default profile): `~/.hermes/config.yaml`
- Profile configs: `~/.hermes/profiles/<profile-name>/config.yaml`
- Secrets: `~/.hermes/.env`
- Skills: `$HERMES_HOME/skills/`
- Sessions: `~/.hermes/sessions/`
- Logs: `~/.hermes/logs/gateway.log`
- Gateway state: `<profile-dir>/gateway_state.json` (PID, status, connected platforms)

## Gateway Config Caching — CRITICAL
**Editing a profile's `config.yaml` alone does NOT change the active model.** The gateway process caches the config at startup. Changes apply only after gateway restart.

### How to find & restart a profile's gateway
```bash
# 1. Find the gateway PID
cat ~/.hermes/profiles/<profile>/gateway_state.json   # shows PID and status
ps aux | grep "hermes.*gateway.*<profile>" | grep -v grep

# 2. Kill the old gateway
kill <pid>

# 3. Start new gateway
hermes --profile <profile> gateway run
# OR with full path if `hermes` isn't in PATH for the profile user:
/usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main --profile <profile> gateway run

# 4. Verify it's running
sleep 3 && cat ~/.hermes/profiles/<profile>/gateway_state.json
# Should show new PID and "connected" platform state
```

### What changes require gateway restart
- `model.default` — primary model
- `model.provider` — provider change (e.g. openrouter → custom litellm)
- `fallback_providers` — fallback chain
- `delegation.model` — subagent model
- Any provider, endpoint, or API key change

## Spawning Additional Hermes Instances
```bash
# One-shot
hermes chat -q "Research topic and write to ~/output.md" timeout=300

# Interactive via tmux
tmux new-session -d -s agent1 -x 120 -y 40 'hermes -w'
tmux send-keys -t agent1 'Build a FastAPI auth service' Enter
tmux capture-pane -t agent1 -p -S -30
```

## Spawning vs delegate_task
| | `delegate_task` | Spawning `hermes` |
|--|-----------------|-------------------|
| Isolation | Shared process | Full process |
| Duration | Minutes | Hours/days |
| Use case | Quick subtasks | Long autonomous missions |

## Docs: https://hermes-agent.nousresearch.com/docs
