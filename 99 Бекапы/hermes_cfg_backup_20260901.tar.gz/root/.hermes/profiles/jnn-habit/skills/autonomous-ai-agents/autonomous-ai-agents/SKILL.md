---
name: autonomous-ai-agents
description: "Delegate coding to AI agents: Claude Code, Codex, OpenCode, Hermes. Orchestration, parallels, PR reviews."
version: 1.0.0
author: Hermes Agent (consolidated)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Coding-Agent, Claude-Code, Codex, OpenCode, Hermes-Agent, Delegation, Autonomous, PR-Review]
    related_skills: [claude-code, codex, opencode, hermes-agent]
---

# Autonomous AI Agents

Delegate coding tasks to AI coding agents orchestrated by Hermes terminal/process tools.

## Agent Map

| Agent | Best For | Skill Reference |
|-------|----------|-----------------|
| **Claude Code** | Full-featured Anthropic agent, multi-turn, `/compact`, hooks, MCP | [references/claude-code.md](references/claude-code.md) |
| **Codex** | OpenAI's autonomous coding CLI, `exec` mode, parallel worktrees | [references/codex.md](references/codex.md) |
| **OpenCode** | Provider-agnostic open-source agent, TUI + CLI | [references/opencode.md](references/opencode.md) |
| **Hermes Agent** | Self-management, spawning, gateway, profiles | [references/hermes-agent.md](references/hermes-agent.md) |

## Common Patterns (All Agents)

### One-Shot Task
```bash
# Claude Code
claude -p "Add error handling to all API calls in src/" --allowedTools "Read,Edit" --max-turns 10

# Codex
codex exec "Add dark mode toggle" --full-auto

# OpenCode
opencode run "Add retry logic to API calls and update tests"
```

### Interactive Session (tmux)
```bash
tmux new-session -d -s agent -x 140 -y 40
tmux send-keys -t agent 'cd /project && claude' Enter
tmux send-keys -t agent 'Task description' Enter
tmux capture-pane -t agent -p -S -60  # Monitor
```

### Parallel Work
```bash
# Multiple Codex instances in worktrees
git worktree add -b fix/issue1 /tmp/issue1 main
codex exec "Fix issue #1" workdir=/tmp/issue1 background=true

# Multiple Claude instances
tmux new-session -d -s task1 && tmux send-keys -t task1 'claude -p "Task 1"' Enter
tmux new-session -d -s task2 && tmux send-keys -t task2 'claude -p "Task 2"' Enter
```

## PR Review Pattern
```bash
# Claude Code
git diff main...feature | claude -p "Review this diff for bugs and security issues" --max-turns 1

# Codex
codex exec "Review PR #86" workdir=/project

# OpenCode
opencode pr 42
```

## Key Rules
1. Use `pty=true` for interactive agents (Codex, OpenCode TUI, Claude Code)
2. Use `--max-turns` / `--max-budget-usd` for one-shot mode
3. Prefer worktrees for parallel agent work
4. Monitor with `process(action=poll)` and `tmux capture-pane`
5. Clean up tmux sessions when done

## References

- `references/claude-code.md` — Claude Code CLI: `-p` print mode, PTY/tmux, MCP, hooks, slash commands
- `references/codex.md` — OpenAI Codex CLI: `exec`, `--full-auto`, `--yolo`, worktrees, PR reviews
- `references/opencode.md` — OpenCode CLI: `run`, TUI, resuming sessions, parallel work
- `references/hermes-agent.md` — Hermes self-management: CLI, config, gateway, profiles, spawning
