# Codex CLI — Condensed Reference

## Key Flags
| Flag | Purpose |
|------|---------|
| `exec "prompt"` | One-shot execution |
| `--full-auto` | Auto-approve changes (sandboxed) |
| `--yolo` | No sandbox, no approvals (fastest, most dangerous) |
| `--sandbox danger-full-access` | No bubblewrap (for gateway/service contexts) |

## One-Shot
```bash
codex exec "Add dark mode toggle" --full-auto
```

## Background (Long Tasks)
```bash
codex exec --full-auto "Refactor auth module" workdir=~/project background=true pty=true
process(action=poll, session_id="<id>")
process(action=submit, session_id="<id>", data="yes")  # Answer prompts
```

## PR Reviews
```bash
REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW \
  && cd $REVIEW && gh pr checkout 42 && codex review --base origin/main
```

## Parallel Work with Worktrees
```bash
git worktree add -b fix/issue-78 /tmp/issue-78 main
codex exec --yolo "Fix #78. Commit." workdir=/tmp/issue-78 background=true pty=true
# After completion: push and create PR, then git worktree remove
```

## Rules
1. Always `pty=true` — Codex is an interactive terminal app
2. Must be inside a git repo
3. `exec` for one-shots, interactive for iteration
4. Background for long tasks with monitoring
