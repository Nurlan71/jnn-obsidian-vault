# Claude Code — Condensed Reference

## Two Modes
- **Print mode (`-p`)** — One-shot, non-interactive, structured output. PREFERRED for automation.
- **Interactive PTY** — Full conversational REPL via tmux. For multi-turn work.

## Key Flags
| Flag | Purpose |
|------|---------|
| `-p "query"` | Print mode (one-shot) |
| `--allowedTools "Read,Edit"` | Whitelist tools |
| `--max-turns N` | Limit agentic loops |
| `--max-budget-usd N` | Cost cap |
| `--dangerously-skip-permissions` | Auto-approve (print mode skips dialogs) |
| `--output-format json` | Structured output |
| `--model haiku/sonnet/opus` | Model selection |
| `--fallback-model haiku` | Auto-fallback on overload |
| `--bare` | Fastest startup (no hooks/plugins/MCP) |
| `--mcp-config path` | Load MCP servers |
| `-c` / `-r ID` | Resume session |

## Dialog Handling (Interactive Only)
- **Trust dialog**: `tmux send-keys -t session Enter` (default = Yes)
- **Permissions bypass dialog**: `tmux send-keys -t session Down && sleep 0.3 && tmux send-keys -t session Enter`

## Monitoring
```bash
tmux capture-pane -t session -p -S -60
# ❯ = waiting for input, ● = actively working
```

## Cost Tips
1. Prefer `-p` for single tasks
2. Use `--max-turns` in print mode
3. Use `--allowedTools Read` for reviews
4. Use `--effort low` for simple tasks
5. Use `/compact` when context > 70%
