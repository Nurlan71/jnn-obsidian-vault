# OpenCode CLI — Condensed Reference

## Key Flags
| Flag | Purpose |
|------|---------|
| `run 'prompt'` | One-shot execution |
| `--model provider/model` | Force specific model |
| `--thinking` | Show model thinking |
| `-c` / `-s <id>` | Resume session |
| `-f <file>` | Attach file(s) |
| `--variant high/max` | Reasoning effort |

## One-Shot
```bash
opencode run 'Add retry logic to API calls' --thinking
opencode run 'Review config for security issues' -f config.yaml
```

## Interactive Background Session
```bash
opencode background=true pty=true workdir=~project
process(action=submit, session_id="<id>", data="Implement OAuth flow")
process(action=log, session_id="<id>")
# Exit: Ctrl+C (\x03) — NEVER use /exit
```

## PR Review
```bash
opencode pr 42 workdir=~/project
```

## Verify
```bash
opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'
```

## Rules
1. Prefer `run` for one-shot (simpler, no pty needed)
2. Interactive needs `pty=true`
3. Resume with `-c` or `-s <id>`
4. Exit with Ctrl+C or kill, NEVER `/exit`
