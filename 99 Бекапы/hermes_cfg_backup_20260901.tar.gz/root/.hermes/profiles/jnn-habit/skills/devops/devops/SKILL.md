---
name: devops
description: "DevOps: Kanban multi-agent orchestration, worker task management."
version: 1.0.0
author: Hermes Agent (consolidated)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [DevOps, Kanban, Multi-Agent, Orchestration, Task-Management]
    related_skills: [kanban-orchestrator, kanban-worker]
---

# DevOps

Multi-agent orchestration and task management via Kanban boards.

## Skill Map

| Skill | Description |
|-------|-------------|
| Kanban Orchestrator | Board management, task dispatch, worker coordination |
| Kanban Worker | Task claiming, progress reporting, completion |

## Quick Reference: Kanban CLI
```bash
hermes kanban init                    # Initialize board
hermes kanban create "Task title"     # Create task
hermes kanban list                    # List tasks
hermes kanban assign <id> <worker>    # Assign task
hermes kanban complete <id>           # Mark complete
hermes kanban block <id>              # Block task
hermes kanban tail                    # Watch board activity
```

## Worker Toolset
Workers get `kanban_show`, `kanban_complete`, `kanban_block`, `kanban_heartbeat`, `kanban_comment`, `kanban_create`, `kanban_link` tools.
Orchestrator profiles additionally get `kanban_list` and `kanban_unblock`.
