---
name: jnn-agent-ops
description: "Operating and troubleshooting the JNN multi-agent Hermes host: per-profile config.yaml model settings, gateway systemd units, diagnosing openrouter fallback, restoring lost profile configs, cross-agent requests."
---

# JNN Multi-Agent Host Operations

The JNN factory runs 8 Hermes agent profiles on one Linux host (navigator, rop, sales, habit, finance, production, marketer, hr). This skill covers profile/gateway operations and cross-agent coordination mechanics. Companion to `habit-tracking` (metrics workflow) and the Kanban `devops` skill.

## Profile layout

- Profiles: `/root/.hermes/profiles/jnn-{navigator,rop,sales,habit,finance,production,marketer,hr}/`
- Each profile's model settings live in ITS OWN `config.yaml`. The global `/root/.hermes/config.yaml` does NOT drive agent models.
- Working model block (identical across profiles; this is the restore template):
  ```yaml
  model:
    api_key: ${DEEPSEEK_API_KEY}
    base_url: https://api.deepseek.com/v1
    default: deepseek-v4-flash
    provider: custom
    max_tokens: 16000
  fallback_providers:
    - model: groq/llama-3.1-8b-instruct
      provider: custom
      base_url: https://api.groq.com/openai/v1
      api_key: ${GROQ_API_KEY}
  delegation:
    model: deepseek-v4-pro   # Navigator delegates complex work to pro
  ```
- Keys: `DEEPSEEK_API_KEY` / `GROQ_API_KEY` in `/root/.env` (system units use `EnvironmentFile=/root/.env`) and in user-systemd environment (`systemctl --user show-environment`).

## Gateway process layout (verified 2026-08-04)

- navigator → USER systemd: `hermes-gateway-jnn-navigator.service`
- finance/habit/hr/marketer/production/rop/sales → SYSTEM systemd: `hermes-gateway-jnn-<name>.service`
- NEVER run two gateways for one profile (gateway.lock conflict → auto-restart loop). Watch for duplicate user+system units of the same profile.
- Restarting/killing ANY gateway from inside a gateway session is BLOCKED by Hermes ("cannot restart or stop the gateway from inside the gateway process"). Give the user the exact external-shell command, or run from cron / an external shell.

## Symptom: agent fell back to openrouter / empty model

Seen 2026-08-01: Navigator printed `◆ Provider: openrouter, ◆ Model: `` ` after a session reset, though it should run deepseek.

**Root cause:** the profile's `config.yaml` was MISSING (only `config.yaml.bak*` from July remained) → Hermes falls back to built-in defaults (openrouter, empty model).

Diagnose:
1. `ls /root/.hermes/profiles/<profile>/config.yaml*` — if only `.bak` files remain, the config is gone.
2. Confirm the last good model: `sqlite3 <profile>/state.db "SELECT model, billing_provider, billing_base_url FROM sessions ORDER BY started_at DESC LIMIT 3;"` (e.g. `deepseek/deepseek-v4-pro`, `custom`).
3. Compare sibling profiles: `grep -A6 "^model:" /root/.hermes/profiles/jnn-*/config.yaml` — they are identical apart from `command_allowlist`/`onboarding`.

Fix:
1. `cp /root/.hermes/profiles/jnn-habit/config.yaml /root/.hermes/profiles/<broken>/config.yaml` (jnn-habit is a current, complete template).
2. Restart the gateway from an EXTERNAL shell:
   - user unit: `XDG_RUNTIME_DIR=/run/user/0 systemctl --user restart hermes-gateway-jnn-navigator`
   - system unit: `systemctl restart hermes-gateway-jnn-<name>`
3. Verify: `systemctl --user is-active hermes-gateway-jnn-navigator` and tail the gateway log for the new session model.

## Cross-agent requests

No direct agent-to-agent messaging. Channels other agents actually read (use ALL THREE for anything critical):
1. Event bus: `python3 /root/.hermes/skills/jnn_emit_event.py <AGENT> <event_type> '{json}'`
2. Shared inbox files: `/opt/shared/requests/YYYY-MM-DD_<agent>_<topic>.md`
3. Shared log: `/opt/shared/agent-logs/log.sh "<AGENT>" "<ACTION>" "<details>"` — Navigator reads all-agents.log in his daily briefings.

Follow up in the user chat; the user pinging Navigator in the common chat speeds things up.

## Pitfalls

- Do NOT attempt gateway restart/kill from inside a gateway session — blocked by design; hand the exact command to the user instead.
- Don't hack GitHub tokens locally for the obsidian-vault repo — access is provisioned via Navigator (procedure in `habit-tracking`).
- After restoring `config.yaml`, only the gateway restart is needed; the global config is irrelevant to agent models.
