# Pre-Commit Code Verification — Condensed Reference

Automated verification pipeline before code lands: static scans, baseline-aware quality gates, independent reviewer subagent, auto-fix loop.

## Pipeline

1. **Get diff**: `git diff --cached` (or `git diff HEAD`)
2. **Static security scan**: grep for hardcoded secrets, shell injection, eval/exec, pickle.loads, SQL injection patterns
3. **Baseline tests**: Run tests before/after, only NEW failures block
4. **Self-review checklist**: No secrets, input validation, parameterized queries, error handling, no debug prints, tests exist
5. **Independent reviewer subagent**: `delegate_task` with diff + scan results, returns JSON verdict
6. **Auto-fix loop**: Max 2 cycles of fix-and-reverify
7. **Commit**: `git add -A && git commit -m "[verified] description"`

## Security Scan Patterns

```bash
git diff --cached | grep "^+" | grep -iE "(api_key|secret|password|token)\s*=\s*['\"][^'\"]{6,}['\"]"
git diff --cached | grep "^+" | grep -E "os\.system\(|subprocess.*shell=True"
git diff --cached | grep "^+" | grep -E "\beval\(|\bexec\("
git diff --cached | grep "^+" | grep -E "execute\(f\"|\.format\(.*SELECT"
```
