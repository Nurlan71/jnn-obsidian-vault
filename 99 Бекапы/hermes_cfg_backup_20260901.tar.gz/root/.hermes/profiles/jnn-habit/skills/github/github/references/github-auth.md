# GitHub Authentication — Condensed Reference

## Detection Flow
```bash
gh --version && gh auth status 2>/dev/null
git config --global credential.helper 2>/dev/null
```

## Auth Methods (in order of preference)

### 1. gh CLI Auth
```bash
gh auth login                          # Interactive (browser)
echo "$TOKEN" | gh auth login --with-token  # Headless
gh auth setup-git                      # Configure git credentials
```

### 2. HTTPS with Personal Access Token
- Create token at: https://github.com/settings/tokens
- Required scopes: `repo`, `workflow`, `read:org`
- Store: `git config --global credential.helper store`

### 3. SSH Key Authentication
```bash
ssh-keygen -t ed25519 -C "email" -f ~/.ssh/id_ed25519 -N ""
# Add public key at: https://github.com/settings/keys
git config --global url."git@github.com:".insteadOf "https://github.com/"
```

## Git Identity (required for commits)
```bash
git config --global user.name "Name"
git config --global user.email "email@example.com"
```

## Troubleshooting
- `git push` asks for password → Use PAT, not GitHub password
- `Permission denied` → Token lacks `repo` scope
- `Authentication failed` → Cached credentials stale, re-authenticate
- `ssh: connect refused` → Try SSH over HTTPS port 443
