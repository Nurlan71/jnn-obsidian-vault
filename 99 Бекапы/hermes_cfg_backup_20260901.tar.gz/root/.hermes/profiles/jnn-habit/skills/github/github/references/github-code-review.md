# GitHub Code Review — Condensed Reference

## Local (Pre-Push) Review

```bash
git diff main...HEAD --stat      # Scope
git diff main...HEAD             # Full diff
git diff main...HEAD --name-only # File list

# Check for issues
git diff main...HEAD | grep -n "print(\|console\.log\|TODO\|FIXME\|debugger"
git diff main...HEAD | grep -in "password\|secret\|api_key\|token.*="
```

### Review Output Format
```
## Code Review Summary
### Critical — issues that must be fixed
### Warnings — should fix before merge
### Suggestions — non-blocking improvements
### Looks Good — what's working well
```

## PR Review on GitHub

```bash
gh pr view 123 && gh pr diff 123
git fetch origin pull/123/head:pr-123 && git checkout pr-123  # Full local checkout

# Inline comment
HEAD_SHA=$(gh pr view 123 --json headRefOid --jq '.headRefOid')
gh api repos/$OWNER/$REPO/pulls/123/comments --method POST \
  -f body="Review comment" -f path="src/file.py" \
  -f commit_id="$HEAD_SHA" -f line=45 -f side="RIGHT"

# Formal review
gh pr review 123 --approve --body "LGTM"
gh pr review 123 --request-changes --body "See inline comments."
```

## Review Checklist
- **Correctness** — Edge cases, error paths, race conditions
- **Security** — No hardcoded secrets, input validation, parameterized queries
- **Code Quality** — Clear naming, DRY, single responsibility
- **Testing** — New code has tests, happy + error paths
- **Performance** — No N+1, unnecessary loops, appropriate caching
- **Documentation** — Public APIs documented, "why" comments for non-obvious logic
