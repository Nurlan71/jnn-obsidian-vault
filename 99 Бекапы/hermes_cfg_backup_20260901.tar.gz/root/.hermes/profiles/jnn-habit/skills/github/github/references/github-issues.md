# GitHub Issues — Condensed Reference

## View / Search

```bash
gh issue list [--state open --label bug --assignee @me]
gh issue list --search "query" --state all
gh issue view 42

# Via API
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/$OWNER/$REPO/issues?state=open&per_page=20"
```

## Create

```bash
gh issue create --title "Title" --body "Description" --label "bug,backend" --assignee "user"

# Via API
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/issues \
  -d '{"title":"Title","body":"Description","labels":["bug"],"assignees":["user"]}'
```

## Manage

```bash
# Labels
gh issue edit 42 --add-label "priority:high,bug"
gh issue edit 42 --remove-label "needs-triage"

# Assign
gh issue edit 42 --add-assignee username

# Comment
gh issue comment 42 --body "Update: working on fix"

# Close / Reopen
gh issue close 42 [--reason "not planned"]
gh issue reopen 42

# Link to PR (auto-close on merge)
# Include in PR body: Closes #42 / Fixes #42 / Resolves #42
```

## Triage Workflow
1. `gh issue list --label "needs-triage" --state open`
2. Read each: `gh issue view N`
3. Apply labels, assign, comment
4. Bulk close: `gh issue list --label "wontfix" --json number --jq '.[].number' | xargs -I {} gh issue close {} --reason "not planned"`
