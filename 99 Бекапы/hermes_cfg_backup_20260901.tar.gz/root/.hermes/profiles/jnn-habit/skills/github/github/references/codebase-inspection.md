# Codebase Inspection (pygount) — Condensed Reference

## Basic Usage

```bash
pip install pygount
cd /path/to/repo
pygount --format=summary \
  --folders-to-skip=".git,node_modules,venv,.venv,__pycache__,.cache,dist,build" .
```

## Common Exclusions

| Project Type | Skip Pattern |
|---|---|
| Python | `.git,venv,.venv,__pycache__,.cache,dist,build,.tox,.mypy_cache` |
| JS/TS | `.git,node_modules,dist,build,.next,.cache,.turbo,coverage` |
| General | `.git,node_modules,venv,.venv,__pycache__,.cache,dist,build,vendor` |

## Output Columns
- **Language**, **Files**, **Code** lines, **Comment** lines, **%** of total
- Special: `__empty__`, `__binary__`, `__generated__`, `__duplicate__`, `__unknown__`

## Pitfalls
1. Always exclude `.git`, `node_modules`, `venv` — otherwise hangs on large repos
2. Markdown shows 0 code lines (all classified as comments — expected)
3. For large monorepos, use `--suffix=py` to target specific languages
