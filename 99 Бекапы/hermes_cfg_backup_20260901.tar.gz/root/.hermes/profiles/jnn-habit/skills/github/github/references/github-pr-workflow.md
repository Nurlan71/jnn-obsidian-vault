# GitHub PR Lifecycle — Condensed Reference

## Branch → Commit → Push → PR

```bash
git fetch origin && git checkout main && git pull origin main
git checkout -b feat/description    # or fix/docs/refactor/ci
# ... make changes (use write_file/patch) ...
git add src/auth.py tests/test_auth.py
git commit -m "feat: add JWT authentication"
git push -u origin HEAD
gh pr create --title "feat: add JWT auth" --body "## Summary\n...\n\nCloses #42"
```

## CI Monitoring

```bash
gh pr checks           # One-shot
gh pr checks --watch   # Poll until done

# Auto-fix loop: check CI → read logs → fix → push → re-check (max 3 attempts)
```

## Merge

```bash
gh pr merge --squash --delete-branch
# Enable auto-merge: gh pr merge --auto --squash --delete-branch
```

## Via API (no gh)

```bash
# Create PR
BRANCH=$(git branch --show-current)
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/pulls \
  -d "{\"title\":\"feat: ...\",\"body\":\"...\",\"head\":\"$BRANCH\",\"base\":\"main\"}"

# Merge
curl -s -X PUT -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/pulls/$PR_NUMBER/merge \
  -d '{"merge_method":"squash","commit_title":"feat: ... (#'$PR_NUMBER')"}'
```
