# GitHub Repository Management — Condensed Reference

## Clone / Create / Fork

```bash
# Clone
git clone https://github.com/owner/repo.git
gh repo clone owner/repo

# Create (gh)
gh repo create name --public --clone

# Create (API)
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/user/repos \
  -d '{"name":"repo","private":false,"auto_init":true,"license_template":"mit"}'

# Fork
gh repo fork owner/repo --clone
# Sync fork: git fetch upstream && git checkout main && git merge upstream/main && git push origin main
```

## Releases

```bash
gh release create v1.0.0 --title "v1.0.0" --generate-notes
# Upload asset: gh release upload v1.0.0 ./binary

# Via API
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/releases \
  -d '{"tag_name":"v1.0.0","generate_release_notes":true}'
```

## Secrets (GitHub Actions)

```bash
gh secret set API_KEY --body "value"
gh secret list
```

## GitHub Actions

```bash
gh workflow list
gh run list --limit 10
gh run view <RUN_ID> --log-failed
gh run rerun <RUN_ID>
```

## Gists

```bash
gh gist create script.py --public --desc "Description"
gh gist list
```
