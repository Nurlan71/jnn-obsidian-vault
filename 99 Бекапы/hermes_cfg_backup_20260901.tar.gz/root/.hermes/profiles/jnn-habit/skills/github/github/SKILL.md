---
name: github
description: "Complete GitHub workflow: auth, repos, issues, PRs, code review, CI/CD, codebase inspection."
version: 1.0.0
author: Hermes Agent (consolidated)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [GitHub, Git, Repositories, Issues, Pull-Requests, Code-Review, CI/CD, Authentication]
    related_skills: [github-auth, github-code-review, github-issues, github-pr-workflow, github-repo-management, codebase-inspection, requesting-code-review]
---

# GitHub — Complete Workflow

End-to-end GitHub operations: authentication, repository management, issues, pull requests, code review, CI/CD, and codebase inspection. Each section shows `gh` CLI first, then `git` + `curl` fallback.

## Skill Map

| Topic | Reference |
|-------|-----------|
| Authentication & setup | [references/github-auth.md](references/github-auth.md) |
| Repository management (clone, create, fork, releases, secrets) | [references/github-repo-management.md](references/github-repo-management.md) |
| Issues (create, triage, label, assign, bulk ops) | [references/github-issues.md](references/github-issues.md) |
| PR lifecycle (branch, commit, open, CI, merge) | [references/github-pr-workflow.md](references/github-pr-workflow.md) |
| Code review (local + PR, inline comments, formal review) | [references/github-code-review.md](references/github-code-review.md) |
| Pre-commit verification (security scan, quality gates, auto-fix) | [references/requesting-code-review.md](references/requesting-code-review.md) |
| Codebase inspection (LOC, language breakdown, ratios) | [references/codebase-inspection.md](references/codebase-inspection.md) |

## Quick Auth Detection

```bash
if command -v gh &>/dev/null && gh auth status &>/dev/null; then
  AUTH="gh"
else
  AUTH="git"
  # Ensure we have a token for API calls
  if [ -z "$GITHUB_TOKEN" ]; then
    if [ -f ~/.hermes/.env ] && grep -q "^GITHUB_TOKEN=" ~/.hermes/.env; then
      export GITHUB_TOKEN=$(grep "^GITHUB_TOKEN=" ~/.hermes/.env | head -1 | cut -d= -f2 | tr -d '\n\r')
    elif grep -q "github.com" ~/.git-credentials 2>/dev/null; then
      export GITHUB_TOKEN=$(grep "github.com" ~/.git-credentials 2>/dev/null | head -1 | sed 's|https://[^:]*:\([^@]*\)@.*|\1|')
    fi
  fi
fi
```

## Extract Owner/Repo

```bash
REMOTE_URL=$(git remote get-url origin)
OWNER_REPO=$(echo "$REMOTE_URL" | sed -E 's|.*github\.com[:/]||; s|\.git$||')
OWNER=$(echo "$OWNER_REPO" | cut -d/ -f1)
REPO=$(echo "$OWNER_REPO" | cut -d/ -f2)
```

## Common Patterns

### Create a feature branch, push, open PR, monitor CI, merge

```bash
git checkout main && git pull origin main
git checkout -b feat/my-feature
# ... make changes ...
git add . && git commit -m "feat: description"
git push -u origin HEAD
gh pr create --title "feat: description" --body "Closes #N"
gh pr checks --watch
gh pr merge --squash --delete-branch
```

### Review a PR

```bash
gh pr view 123
gh pr diff 123
git fetch origin pull/123/head:pr-123 && git checkout pr-123
# Review files, run tests, then:
gh pr review 123 --approve --body "LGTM"
# or
gh pr review 123 --request-changes --body "See inline comments."
```

### Triage issues

```bash
gh issue list --label "needs-triage" --state open
gh issue view 42
gh issue edit 42 --add-label "priority:high,bug" --add-assignee @me
```

## References

- `references/github-auth.md` — HTTPS tokens, SSH keys, gh CLI login, API auth detection
- `references/github-repo-management.md` — Clone, create, fork, releases, secrets, Actions, Gists
- `references/github-issues.md` — Create, search, triage, label, assign, comment, close, bulk ops
- `references/github-pr-workflow.md` — Branch, commit, push, create PR, CI monitoring, merge
- `references/github-code-review.md` — Local review, PR review, inline comments, formal review
- `references/requesting-code-review.md` — Pre-commit security scan, quality gates, auto-fix loop
- `references/codebase-inspection.md` — pygount LOC analysis, language breakdown, ratios
