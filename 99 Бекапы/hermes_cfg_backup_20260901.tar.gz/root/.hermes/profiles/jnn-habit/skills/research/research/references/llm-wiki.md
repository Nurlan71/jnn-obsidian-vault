# LLM Wiki (Karpathy Pattern) — Condensed Reference

Build and maintain a persistent, compounding knowledge base as interlinked markdown files.

## Architecture
```
wiki/
├── SCHEMA.md          # Conventions, structure rules
├── index.md           # Sectioned content catalog
├── log.md             # Chronological action log
├── raw/               # Layer 1: Immutable sources
│   ├── articles/, papers/, transcripts/, assets/
├── entities/          # Layer 2: Entity pages
├── concepts/          # Layer 2: Concept pages
├── comparisons/       # Layer 2: Side-by-side analyses
└── queries/           # Layer 2: Filed query results
```

## Core Operations
1. **Ingest** — Capture raw source → discuss takeaways → check existing → write/update pages → update index + log
2. **Query** — Read index → search → read pages → synthesize → file valuable answers
3. **Lint** — Orphan pages, broken links, index completeness, frontmatter, stale content, contradictions

## Key Rules
- Never modify files in `raw/` — sources are immutable
- Always orient first: read SCHEMA + index + recent log
- Every page must link to ≥2 other pages via `[[wikilinks]]`
- Tags must come from the taxonomy in SCHEMA.md
- Rotate log when >500 entries
