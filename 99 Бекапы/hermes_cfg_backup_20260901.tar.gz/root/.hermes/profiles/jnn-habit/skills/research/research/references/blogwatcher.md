# Blogwatcher — Condensed Reference

Monitor blog and RSS/Atom feed updates.

## Install
```bash
go install github.com/JulienTant/blogwatcher-cli/cmd/blogwatcher-cli@latest
```

## Usage
```bash
blogwatcher-cli add "Blog Name" https://example.com
blogwatcher-cli add "Blog" https://example.com --feed-url https://example.com/feed.xml
blogwatcher-cli scan
blogwatcher-cli articles
blogwatcher-cli read 1
blogwatcher-cli import subscriptions.opml
```

## Database
`~/.blogwatcher-cli/blogwatcher-cli.db` (override with `BLOGWATCHER_DB`)
