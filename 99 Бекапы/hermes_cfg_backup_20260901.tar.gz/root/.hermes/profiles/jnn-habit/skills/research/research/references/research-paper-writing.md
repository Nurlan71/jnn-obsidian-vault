# Research Paper Writing — Condensed Reference

End-to-end pipeline for producing publication-ready ML/AI papers (NeurIPS, ICML, ICLR, ACL, AAAI, COLM).

## Pipeline (Iterative)
1. **Experiment design** — Hypothesis, metrics, baselines
2. **Execution** — Run experiments, log results
3. **Analysis** — Statistical tests, ablation studies
4. **Writing** — LaTeX template, figures, tables
5. **Review** — Self-review checklist, co-author feedback
6. **Revision** → Iterate
7. **Submission** — Format check, supplementary, rebuttal

## Key Dependencies
`semanticscholar`, `arxiv`, `habanero`, `scipy`, `numpy`, `matplotlib`, `SciencePlots`

## Target Venues
NeurIPS, ICML, ICLR, ACL, AAAI, COLM
