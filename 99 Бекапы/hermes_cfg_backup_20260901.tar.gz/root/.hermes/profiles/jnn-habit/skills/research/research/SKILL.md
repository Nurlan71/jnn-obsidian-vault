---
name: research
description: "Academic research: arXiv search, paper writing, blog monitoring, prediction markets, knowledge bases."
version: 1.0.0
author: Hermes Agent (consolidated)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Research, Arxiv, Papers, Academic, Blog-Monitoring, Prediction-Markets, Knowledge-Base]
    related_skills: [arxiv, blogwatcher, llm-wiki, polymarket, research-paper-writing]
---

# Research

Academic research tools: paper discovery, literature review, blog monitoring, prediction markets, and knowledge base construction.

## Skill Map

| Topic | Reference |
|-------|-----------|
| arXiv search + Semantic Scholar | [references/arxiv.md](references/arxiv.md) |
| Blog/RSS monitoring | [references/blogwatcher.md](references/blogwatcher.md) |
| LLM Wiki (Karpathy pattern) | [references/llm-wiki.md](references/llm-wiki.md) |
| Polymarket prediction markets | [references/polymarket.md](references/polymarket.md) |
| ML paper writing pipeline | [references/research-paper-writing.md](references/research-paper-writing.md) |

## Quick Reference: arXiv Search
```bash
# Search
curl -s "https://export.arxiv.org/api/query?search_query=all:GRPO+reinforcement+learning&max_results=5"

# With Python parsing (see full reference for snippet)
# Categories: cs.AI, cs.CL, cs.CV, cs.LG, stat.ML
# Rate limit: ~1 req / 3 seconds
```

## Quick Reference: Blog Monitoring
```bash
blogwatcher-cli add "Blog Name" https://example.com
blogwatcher-cli scan
blogwatcher-cli articles
```

## Quick Reference: Polymarket
```bash
# Search markets
curl -s "https://gamma-api.polymarket.com/markets?limit=10&active=true"
# Prices ARE probabilities: 0.65 = 65%
```

## References
- `references/arxiv.md` — Search syntax, parsing, BibTeX, Semantic Scholar integration
- `references/blogwatcher.md` — Feed management, scanning, OPML import
- `references/llm-wiki.md` — Karpathy wiki pattern, schema, ingest, query, lint
- `references/polymarket.md` — Gamma/CLOB/Data APIs, market data, rate limits
- `references/research-paper-writing.md` — End-to-end ML paper pipeline
