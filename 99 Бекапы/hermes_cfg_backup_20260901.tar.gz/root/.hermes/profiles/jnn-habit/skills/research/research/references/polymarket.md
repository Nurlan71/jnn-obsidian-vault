# Polymarket — Condensed Reference

Query prediction market data from Polymarket (read-only, no auth needed).

## Three APIs
1. **Gamma API** (`gamma-api.polymarket.com`) — Discovery, search
2. **CLOB API** (`clob.polymarket.com`) — Real-time prices, orderbooks
3. **Data API** (`data-api.polymarket.com`) — Trades, open interest

## Search Markets
```bash
curl -s "https://gamma-api.polymarket.com/markets?limit=10&active=true"
curl -s "https://gamma-api.polymarket.com/events?active=true&closed=false&limit=20"
```

## Get Prices
```bash
# outcomePrices field: JSON-encoded array like ["0.65", "0.35"]
# Price = probability: 0.65 means 65% likely
curl -s "https://gamma-api.polymarket.com/markets?limit=5" | python3 -c "
import sys, json
for m in json.load(sys.stdin):
    prices = json.loads(m['outcomePrices'])
    print(f\"{m['question']}: {prices}\")
"
```

## Rate Limits
- Gamma: 4,000 req / 10 seconds
- CLOB: 9,000 req / 10 seconds
- Data: 1,000 req / 10 seconds
