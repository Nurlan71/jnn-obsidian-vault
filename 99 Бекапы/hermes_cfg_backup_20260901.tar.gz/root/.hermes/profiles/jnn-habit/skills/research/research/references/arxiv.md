# arXiv Research — Condensed Reference

## Search
```bash
curl -s "https://export.arxiv.org/api/query?search_query=all:QUERY&max_results=5&sortBy=submittedDate&sortOrder=descending"
curl -s "https://export.arxiv.org/api/query?id_list=2402.03300"
```

## Query Syntax
| Prefix | Searches |
|--------|----------|
| `all:` | All fields |
| `ti:` | Title |
| `au:` | Author |
| `cat:` | Category |

Boolean: `AND`, `OR`, `ANDNOT`, `"exact phrase"`

## Categories
`cs.AI`, `cs.CL`, `cs.CV`, `cs.LG`, `stat.ML`, `cs.CR`

## Semantic Scholar (citations, recommendations)
```bash
curl -s "https://api.semanticscholar.org/graph/v1/paper/arXiv:2402.03300?fields=title,authors,citationCount"
curl -s "https://api.semanticscholar.org/graph/v1/paper/arXiv:2402.03300/citations?fields=title,year&limit=10"
```

## Read Papers
```
web_extract(urls=["https://arxiv.org/abs/2402.03300"])   # Abstract
web_extract(urls=["https://arxiv.org/pdf/2402.03300"])   # Full paper
```

## Rate Limits
- arXiv: ~1 req / 3 seconds
- Semantic Scholar: 1 req / second
