# Excalidraw Diagrams — Condensed Reference

Create `.excalidraw` files by writing standard Excalidraw element JSON.

## File Format
```json
{
  "type": "excalidraw",
  "version": 2,
  "source": "hermes-agent",
  "elements": [ ... ],
  "appState": { "viewBackgroundColor": "#ffffff" }
}
```

## Element Types
- **Rectangle**: `{ "type": "rectangle", "id": "r1", "x": 100, "y": 100, "width": 200, "height": 100 }`
- **Ellipse**, **Diamond**: same pattern
- **Labeled shape**: Use container binding (`boundElements` + `containerId`), NOT `label` property
- **Arrow**: `{ "type": "arrow", "points": [[0,0],[200,0]], "endArrowhead": "arrow" }`

## Sizing
- Minimum fontSize: 16 (body), 20 (titles), 14 (annotations only)
- Minimum shape: 120x60 for labeled rectangles
- 20-30px gaps between elements

## Color Palette
| Use | Fill |
|-----|------|
| Primary/Input | `#a5d8ff` (light blue) |
| Success/Output | `#b2f2bb` (light green) |
| Warning/External | `#ffd8a8` (light orange) |
| Processing | `#d0bfff` (light purple) |
| Error/Critical | `#ffc9c9` (light red) |

## Upload for Shareable Link
```bash
python skills/diagramming/excalidraw/scripts/upload.py ~/diagrams/my_diagram.excalidraw
```
