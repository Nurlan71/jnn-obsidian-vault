# Architecture Diagrams — Condensed Reference

Generate dark-themed SVG/HTML architecture diagrams.

## Color Palette
| Component | Fill (rgba) | Stroke (Hex) |
|-----------|-------------|--------------|
| Frontend | `rgba(8, 51, 68, 0.4)` | `#22d3ee` (cyan) |
| Backend | `rgba(6, 78, 59, 0.4)` | `#34d399` (emerald) |
| Database | `rgba(76, 29, 149, 0.4)` | `#a78bfa` (violet) |
| AWS/Cloud | `rgba(120, 53, 15, 0.3)` | `#fbbf24` (amber) |
| Security | `rgba(136, 19, 55, 0.4)` | `#fb7185` (rose) |
| Message Bus | `rgba(251, 146, 60, 0.3)` | `#fb923c` (orange) |
| External | `rgba(30, 41, 59, 0.5)` | `#94a3b8` (slate) |

## Key Rules
- Background: `#020617` (slate-950) with 40px grid pattern
- Font: JetBrains Mono (12px names, 9px sublabels, 8px annotations)
- Double-rect masking: opaque bg rect + semi-transparent styled rect on top
- Arrows render BEFORE components (z-order)
- Security flows: dashed rose lines
- Legend: place OUTSIDE all boundary boxes

## Output
- Single self-contained `.html` file
- No external dependencies (except Google Fonts)
- No JavaScript — pure CSS animations
- Save to `./project-architecture.html`
