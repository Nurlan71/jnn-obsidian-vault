---
name: creative
description: "Creative content: ASCII art, diagrams, design, video, music, infographics, web mockups."
version: 1.0.0
author: Hermes Agent (consolidated)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Creative, Art, Design, ASCII, Diagrams, HTML, SVG, Music, Video, Infographic]
    related_skills: [architecture-diagram, ascii-art, ascii-video, baoyu-infographic, claude-design, comfyui, design-md, excalidraw, humanizer, manim-video, p5js, popular-web-designs, pretext, sketch, songwriting-and-ai-music, touchdesigner-mcp]
---

# Creative Content Generation

Multi-modal creative generation: ASCII art, architecture diagrams, HTML mockups, video, music, infographics, and interactive demos.

## Skill Map

| Category | Tools | Reference |
|----------|-------|-----------|
| ASCII art & banners | pyfiglet, cowsay, boxes, asciified API, image-to-ascii | [references/ascii-art.md](references/ascii-art.md) |
| Architecture diagrams | Dark-themed SVG/HTML diagrams | [references/architecture-diagram.md](references/architecture-diagram.md) |
| ASCII video | Colored ASCII MP4/GIF from video/audio | [references/ascii-video.md](references/ascii-video.md) |
| Infographics | 21 layouts × 21 styles | [references/baoyu-infographic.md](references/baoyu-infographic.md) |
| HTML design artifacts | Landing pages, prototypes, decks, design systems | [references/claude-design.md](references/claude-design.md) |
| ComfyUI | Image/video/audio generation via ComfyUI | [references/comfyui.md](references/comfyui.md) |
| DESIGN.md tokens | Google's DESIGN.md token spec format | [references/design-md.md](references/design-md.md) |
| Hand-drawn diagrams | Excalidraw JSON diagrams | [references/excalidraw.md](references/excalidraw.md) |
| Text humanization | Strip AI-isms, add natural voice | [references/humanizer.md](references/humanizer.md) |
| Math animations | Manim CE (3Blue1Brown style) | [references/manim-video.md](references/manim-video.md) |
| Generative art | p5.js sketches, shaders, 3D | [references/p5js.md](references/p5js.md) |
| Design systems | 54 real systems (Stripe, Linear, Vercel) | [references/popular-web-designs.md](references/popular-web-designs.md) |
| Text layout demos | @chenglou/pretext for DOM-free layout | [references/pretext.md](references/pretext.md) |
| HTML mockups | 2-3 variant comparison sketches | [references/sketch.md](references/sketch.md) |
| Songwriting | Suno AI music prompts, songwriting craft | [references/songwriting.md](references/songwriting.md) |
| TouchDesigner | Real-time visuals via MCP | [references/touchdesigner-mcp.md](references/touchdesigner-mcp.md) |

## Quick Reference: ASCII Art
```bash
# Text banners
python3 -m pyfiglet "TEXT" -f slant
curl -s "https://asciified.thelicato.io/api/v2/ascii?text=Hello"

# Message art
cowsay "Hello"
echo "Hello" | boxes -d stone

# Image to ASCII
ascii-image-converter image.png -C -d 60,30
```

## Quick Reference: Architecture Diagrams
- Generate dark-themed SVG/HTML files with inline CSS
- Color palette: Frontend=cyan, Backend=emerald, Database=violet, Cloud=amber, Security=rose
- Use double-rect masking for semi-transparent components
- Save as `.html`, open in browser

## Quick Reference: HTML Mockups
- 2-3 variants per sketch, self-contained HTML with inline CSS/JS
- System fonts or one Google Font
- Realistic fake content (no Lorem ipsum)
- Interactive: clickable, hovers, state transitions

## References
- `references/ascii-art.md` — pyfiglet, cowsay, boxes, toilet, image-to-ascii, ascii.co.uk
- `references/architecture-diagram.md` — SVG design system, color palette, layout rules
- `references/claude-design.md` — Design process, artifact format, anti-slop rules
- `references/excalidraw.md` — Element JSON format, sizing, colors, upload
- `references/sketch.md` — Variant workflow, theming, verification
- `references/songwriting.md` — Suno prompts, songwriting craft
