# ASCII Art — Condensed Reference

## Text Banners (pyfiglet)
```bash
pip install pyfiglet
python3 -m pyfiglet "TEXT" -f slant    # Clean & modern
python3 -m pyfiglet "TEXT" -f doom     # Bold & blocky
python3 -m pyfiglet --list_fonts        # 571 fonts
```

## Text Banners (asciified API — no install)
```bash
curl -s "https://asciified.thelicato.io/api/v2/ascii?text=Hello&font=Slant"
curl -s "https://asciified.thelicato.io/api/v2/fonts"  # List fonts
```

## Cowsay
```bash
cowsay "Message"
cowsay -f tux "Linux"    # Characters: tux, dragon, cow, etc.
cowsay -l                # List all characters
```

## Boxes
```bash
echo "Text" | boxes -d stone
echo "Text" | boxes -d cat
boxes -l                 # List 70+ designs
```

## Image to ASCII
```bash
ascii-image-converter image.png -C -d 60,30  # Color, dimensions
jp2a --width=80 image.jpg                     # Lightweight
```

## Pre-made Art (ascii.co.uk)
```bash
curl -s 'https://ascii.co.uk/art/cat' -o /tmp/art.html
# Extract from <pre> tags with Python
```

## QR Codes / Weather
```bash
curl -s "qrenco.de/Hello+World"
curl -s "wttr.in/London"
```
