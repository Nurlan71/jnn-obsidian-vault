# HTML Sketch / Mockup — Condensed Reference

Generate 2-3 interactive HTML mockup variants for design comparison.

## Workflow
1. **Intake** — Get feel, references, core action (one question at a time)
2. **Variants** — 2-3 complete standalone HTML files with different design stances
3. **Make real** — Inline CSS, system fonts, realistic content, interactive
4. **Verify** — Open in browser, check with `browser_vision`
5. **Head-to-head** — Present comparison table with opinionated take

## Variant Axes
- Density: compact / airy / ultra-dense
- Emphasis: content-first / action-first / tool-first
- Aesthetic: editorial / utilitarian / playful
- Layout: single-column / sidebar / split-pane

## Output
```
sketches/
├── 001-stance-name/
│   ├── index.html
│   └── README.md
```

## Interactivity Bar
1. Click primary action → visible state change
2. One meaningful state transition (filter, toggle, open/close)
3. Hover recognizable affordances
