# HTML Design Artifacts — Condensed Reference

Design one-off HTML artifacts: landing pages, prototypes, decks, design systems.

## When to Use
- Landing pages, prototypes, interactive mockups
- Visual option boards, component explorations
- HTML slide decks, motion studies
- Redesigns from screenshots/repos

## Design Process
1. **Understand the brief** — What, who, artifact format, constraints
2. **Gather context** — Read source files, inspect repo, find visual vocabulary
3. **Define design system** — Colors, type, spacing, radii, shadows, motion
4. **Choose format** — Static comparison, clickable prototype, deck, component lab
5. **Build** — Single self-contained HTML file
6. **Verify** — File exists, browser check, console errors
7. **Report** — File path, what was created, verification status

## Anti-Slop Rules
- No aggressive gradient backgrounds by default
- No glassmorphism by default
- No emoji unless brand uses them
- No generic SaaS cards with icons everywhere
- No fake dashboards with arbitrary numbers
- No stock-photo hero sections
- No oversized rounded rectangles
- No rainbow palettes
- No vague labels ("Insights", "Growth", "Scale")

## Output Format
- Single `.html` file with inline `<style>` and `<script>`
- System fonts or one Google Font
- Responsive behavior
- Realistic fake content (no Lorem ipsum)
