---
name: productivity
description: "Productivity tools: Airtable, Google Workspace, Notion, OCR, PDF editing, PowerPoint, Teams, maps."
version: 1.0.0
author: Hermes Agent (consolidated)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Productivity, Airtable, Google-Workspace, Notion, OCR, PDF, PowerPoint, Teams, Maps]
    related_skills: [airtable, google-workspace, notion, ocr-and-documents, nano-pdf, powerpoint, teams-meeting-pipeline, maps]
---

# Productivity Tools

Office and productivity tools: databases, email, documents, presentations, meetings, and maps.

## Skill Map

| Tool | What | Reference |
|------|------|-----------|
| Airtable | REST API, records CRUD, filters, upserts | [references/airtable.md](references/airtable.md) |
| Google Workspace | Gmail, Calendar, Drive, Docs, Sheets | [references/google-workspace.md](references/google-workspace.md) |
| Notion | Pages, databases, Workers | [references/notion.md](references/notion.md) |
| OCR/Documents | PDF/text extraction (pymupdf, marker-pdf) | [references/ocr-and-documents.md](references/ocr-and-documents.md) |
| nano-pdf | Edit PDF text/typos via NL prompts | [references/nano-pdf.md](references/nano-pdf.md) |
| PowerPoint | Create, read, edit .pptx decks | [references/powerpoint.md](references/powerpoint.md) |
| Teams Pipeline | Meeting summaries, Graph subscriptions | [references/teams-meeting-pipeline.md](references/teams-meeting-pipeline.md) |
| Maps | Geocode, POIs, routes, timezones | [references/maps.md](references/maps.md) |

## Quick Reference: Airtable
```bash
# List bases
curl -s "https://api.airtable.com/v0/meta/bases" -H "Authorization: Bearer $AIRTABLE_API_KEY"

# Filter records (URL-encode formula)
FORMULA="{Status}='Todo'"
ENC=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$FORMULA', safe=''))")
curl -s "https://api.airtable.com/v0/$BASE_ID/$TABLE?filterByFormula=$ENC"

# Create record
curl -s -X POST "https://api.airtable.com/v0/$BASE_ID/$TABLE" \
  -H "Authorization: Bearer $AIRTABLE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"fields":{"Name":"Task","Status":"Todo"}}'
```

## Quick Reference: Google Workspace
```bash
# Gmail search
python3 scripts/google_api.py gmail search "is:unread" --max 10

# Calendar list
python3 scripts/google_api.py calendar list

# Drive upload
python3 scripts/google_api.py drive upload /path/to/file.pdf
```

## Quick Reference: Notion
```bash
# Read page as Markdown (agent-friendly)
curl -s "https://api.notion.com/v1/pages/{page_id}/markdown" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03"

# Create page from Markdown
curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{"parent":{"page_id":"xxx"},"properties":{"title":[{"text":{"content":"Notes"}}]},"markdown":"# Content"}'
```

## Quick Reference: Maps
```bash
MAPS=~/.hermes/skills/productivity/maps/scripts/maps_client.py
python3 $MAPS search "Eiffel Tower"
python3 $MAPS nearby 48.8584 2.2945 restaurant --limit 10
python3 $MAPS distance "Paris" --to "Lyon"
```

## References
- `references/airtable.md` — Auth, CRUD, filterByFormula, pagination, upserts
- `references/google-workspace.md` — OAuth setup, Gmail, Calendar, Drive, Sheets, Docs
- `references/notion.md` — Pages, databases, Markdown, Workers, file uploads
- `references/ocr-and-documents.md` — pymupdf vs marker-pdf, split/merge, arXiv
- `references/nano-pdf.md` — Natural language PDF editing
- `references/powerpoint.md` — Read, edit, create slides, design guidelines, QA
- `references/teams-meeting-pipeline.md` — Meeting summaries, subscription management
- `references/maps.md` — Geocoding, nearby search, routing, timezones
