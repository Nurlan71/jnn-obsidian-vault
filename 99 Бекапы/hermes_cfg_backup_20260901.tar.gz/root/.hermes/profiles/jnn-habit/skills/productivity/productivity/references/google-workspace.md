# Google Workspace — Condensed Reference

## Setup
1. Create OAuth credentials at Google Cloud Console
2. Enable APIs: Gmail, Calendar, Drive, Sheets, Docs, People
3. Run setup: `python scripts/setup.py --client-secret /path/to/client_secret.json`
4. Token stored at `~/.hermes/google_token.json`

## Usage
```bash
GAPI="python scripts/google_api.py"

# Gmail
$GAPI gmail search "is:unread" --max 10
$GAPI gmail get MESSAGE_ID
$GAPI gmail send --to user@example.com --subject "Hello" --body "Message"

# Calendar
$GAPI calendar list
$GAPI calendar create --summary "Meeting" --start 2026-03-01T10:00:00-06:00 --end 2026-03-01T10:30:00-06:00

# Drive
$GAPI drive search "report" --max 10
$GAPI drive upload /path/to/file.pdf
$GAPI drive download FILE_ID

# Sheets
$GAPI sheets create --title "Budget"
$GAPI sheets get SHEET_ID "Sheet1!A1:D10"
$GAPI sheets update SHEET_ID "Sheet1!A1:B2" --values '[["Name","Score"],["Alice","95"]]'

# Docs
$GAPI docs create --title "Notes"
$GAPI docs get DOC_ID
```

## Rules
1. Never send email, create/delete calendar events, delete Drive files without confirming first
2. Calendar times must include timezone (ISO 8601)
3. Check auth before first use: `setup.py --check`
