# Airtable — Condensed Reference

## Auth
- Create PAT at: https://airtable.com/create/tokens (starts with `pat...`)
- Scopes: `data.records:read`, `data.records:write`, `schema.bases:read`
- Add each base to the token's Access list
- Store in `~/.hermes/.env`: `AIRTABLE_API_KEY=pat...`

## Common Operations
```bash
# List bases
curl -s "https://api.airtable.com/v0/meta/bases" -H "Authorization: Bearer $AIRTABLE_API_KEY"

# List records
curl -s "https://api.airtable.com/v0/$BASE_ID/$TABLE?maxRecords=10" \
  -H "Authorization: Bearer $AIRTABLE_API_KEY"

# Filter (URL-encode formula)
FORMULA="{Status}='Todo'"
ENC=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$FORMULA', safe=''))")
curl -s "https://api.airtable.com/v0/$BASE_ID/$TABLE?filterByFormula=$ENC" \
  -H "Authorization: Bearer $AIRTABLE_API_KEY"

# Create
curl -s -X POST "https://api.airtable.com/v0/$BASE_ID/$TABLE" \
  -H "Authorization: Bearer $AIRTABLE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"fields":{"Name":"Task","Status":"Todo"}}'

# Update (PATCH merges, PUT replaces)
curl -s -X PATCH "https://api.airtable.com/v0/$BASE_ID/$TABLE/$RECORD_ID" \
  -H "Authorization: Bearer $AIRTABLE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"fields":{"Status":"Done"}}'

# Upsert
curl -s -X PATCH "https://api.airtable.com/v0/$BASE_ID/$TABLE" \
  -H "Authorization: Bearer $AIRTABLE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"performUpsert":{"fieldsToMergeOn":["Email"]},"records":[{"fields":{"Email":"a@b.com","Status":"Active"}}]}'
```

## Pagination
Loop with `offset` until absent. Max 100 records per page.

## Pitfalls
- `filterByFormula` MUST be URL-encoded
- PATCH merges, PUT replaces — default to PATCH
- Single-select options must exist or use `"typecast": true`
- Rate limit: 5 req/sec per base
