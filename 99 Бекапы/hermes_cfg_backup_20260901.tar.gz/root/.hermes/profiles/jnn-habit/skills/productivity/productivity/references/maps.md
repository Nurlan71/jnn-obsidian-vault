# Maps — Condensed Reference

## Commands
```bash
MAPS=~/.hermes/skills/productivity/maps/scripts/maps_client.py

python3 $MAPS search "Eiffel Tower"           # Geocode
python3 $MAPS reverse 48.8584 2.2945          # Reverse geocode
python3 $MAPS nearby 48.8584 2.2945 restaurant --limit 10
python3 $MAPS nearby --near "Times Square" --category cafe
python3 $MAPS distance "Paris" --to "Lyon"
python3 $MAPS directions "Eiffel Tower" --to "Louvre" --mode walking
python3 $MAPS timezone 48.8584 2.2945
python3 $MAPS area "Manhattan"                # Bounding box
python3 $MAPS bbox 40.75 -74.00 40.77 -73.98 restaurant --limit 20
```

## 46 POI Categories
restaurant, cafe, bar, hospital, pharmacy, hotel, supermarket, atm, gas_station, parking, museum, park, school, university, bank, police, fire_station, library, airport, train_station, bus_stop, church, dentist, doctor, cinema, theatre, gym, post_office, bakery, bookshop, laundry, car_wash, car_rental, bicycle_rental, taxi, veterinary, zoo, playground, stadium, nightclub, camp_site, swimming_pool, mosque, synagogue

## Pitfalls
- Nominatim: max 1 req/s (handled automatically)
- OSRM routing best for Europe and North America
