# OCR & Documents — Condensed Reference

## First Choice: web_extract for URLs
```
web_extract(urls=["https://arxiv.org/pdf/2402.03300"])
```

## Local Extraction

### pymupdf (lightweight, ~25MB)
```bash
pip install pymupdf pymupdf4llm
python scripts/extract_pymupdf.py document.pdf --markdown
python scripts/extract_pymupdf.py document.pdf --pages 0-4
```

### marker-pdf (OCR, ~3-5GB)
```bash
pip install marker-pdf
python scripts/extract_marker.py document.pdf
marker_single document.pdf --output_dir ./output
```

## Decision Matrix
| Feature | pymupdf | marker-pdf |
|---------|---------|------------|
| Text PDF | ✅ | ✅ |
| Scanned PDF | ❌ | ✅ |
| Tables | Basic | High accuracy |
| Equations | ✅ | ✅ |
| Install size | ~25MB | ~3-5GB |
| Speed | Instant | ~1-14s/page |

## Split/Merge/Search
Use pymupdf via Python (see full reference for code snippets).
