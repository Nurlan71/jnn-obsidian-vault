# Notion — Condensed Reference

## Auth
- Create integration at: https://notion.so/my-integrations
- Store `NOTION_API_KEY` in `~/.hermes/.env`
- Share target pages with the integration

## Read/Write Pages
```bash
# Read as Markdown
curl -s "https://api.notion.com/v1/pages/{page_id}/markdown" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03"

# Create from Markdown
curl -s -X POST "https://api.notion.com/v1/pages" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{"parent":{"page_id":"xxx"},"properties":{"title":[{"text":{"content":"Title"}}]},"markdown":"# Content"}'

# Query database
curl -s -X POST "https://api.notion.com/v1/data_sources/{data_source_id}/query" \
  -H "Authorization: Bearer $NOTION_API_KEY" \
  -H "Notion-Version: 2025-09-03" \
  -H "Content-Type: application/json" \
  -d '{"filter":{"property":"Status","select":{"equals":"Active"}}}'
```

## API Version 2025-09-03
- Databases are now "data sources"
- Use `database_id` for creating pages, `data_source_id` for querying
- Rate limit: ~3 req/sec
