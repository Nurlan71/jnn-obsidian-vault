# PowerPoint — Condensed Reference

## Reading
```bash
python -m markitdown presentation.pptx
python scripts/thumbnail.py presentation.pptx
```

## Editing
1. Analyze template with `thumbnail.py`
2. Unpack → manipulate → clean → pack

## Creating from Scratch
Use `pptxgenjs` (npm) or `python-pptx` (pip).

## Design Rules
- Pick a bold, content-informed color palette
- One color should dominate (60-70% visual weight)
- Every slide needs a visual element (image, chart, icon, shape)
- Minimum title: 36pt, body: 14pt
- 0.5" minimum margins
- Left-align body text, center only titles
- Vary layouts across slides

## QA (Required)
```bash
python -m markitdown output.pptx | grep -iE "xxxx|lorem|ipsum"
# Convert to images for visual inspection
python scripts/office/soffice.py --headless --convert-to pdf output.pptx
pdftoppm -jpeg -r 150 output.pdf slide
```
