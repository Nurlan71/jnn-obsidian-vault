# Teams Meeting Pipeline — Condensed Reference

## Prerequisites
```bash
MSGRAPH_TENANT_ID=...
MSGRAPH_CLIENT_ID=...
MSGRAPH_CLIENT_SECRET=...
```

## Commands
```bash
hermes teams-pipeline validate              # Config check
hermes teams-pipeline token-health          # Token status
hermes teams-pipeline list                  # Recent jobs
hermes teams-pipeline show <job-id>         # Job detail
hermes teams-pipeline run <job-id>          # Replay job
hermes teams-pipeline subscriptions         # Webhook subscriptions
hermes teams-pipeline subscribe --resource communications/onlineMeetings/getAllTranscripts \
  --notification-url https://host/msgraph/webhook
hermes teams-pipeline maintain-subscriptions # Renew near-expiry
```

## Critical: Graph subscriptions expire in 72 hours
Set up automated renewal via `hermes cron add` (12-hour interval).
