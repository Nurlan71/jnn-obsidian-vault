# HuggingFace Hub — Condensed Reference

## hf CLI
```bash
curl -LsSf https://hf.co/cli/install.sh | bash  # Install
hf download REPO_ID                            # Download
hf upload REPO_ID                              # Upload
hf auth login                                  # Auth
```

## Key Commands
```bash
hf models list / info          # Model info
hf datasets list / info        # Dataset info
hf repos create / delete       # Repo management
hf cache prune                 # Clean cache
```
