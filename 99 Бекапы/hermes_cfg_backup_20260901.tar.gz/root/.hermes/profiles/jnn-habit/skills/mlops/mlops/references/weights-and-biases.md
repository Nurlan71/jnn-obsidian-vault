# Weights & Biases — Condensed Reference

ML experiment tracking, hyperparameter sweeps, model registry.

## Install & Login
```bash
pip install wandb
wandb login
```

## Basic Tracking
```python
import wandb
run = wandb.init(project="my-project", config={"lr": 0.001, "epochs": 10})
for epoch in range(10):
    wandb.log({"loss": train_loss, "val/accuracy": val_acc})
wandb.finish()
```

## Sweeps
```python
sweep_config = {
    'method': 'bayes',
    'metric': {'name': 'val/loss', 'goal': 'minimize'},
    'parameters': {'lr': {'distribution': 'log_uniform', 'min': 1e-5, 'max': 1e-1}}
}
sweep_id = wandb.sweep(sweep_config, project="my-project")
wandb.agent(sweep_id, function=train, count=50)
```
