# vLLM — Condensed Reference

High-throughput LLM serving with PagedAttention and continuous batching.

## Quick Start
```bash
pip install vllm
vllm serve meta-llama/Llama-3-8B-Instruct --gpu-memory-utilization 0.9
# OpenAI-compatible: http://localhost:8000/v1
```

## Key Flags
| Flag | Purpose |
|------|---------|
| `--tensor-parallel-size N` | Multi-GPU serving |
| `--quantization awq/gptq/fp8` | Quantized models |
| `--gpu-memory-utilization 0.9` | KV cache fraction |
| `--max-model-len 4096` | Context length |
| `--enable-prefix-caching` | Repeated prompt prefix |
| `--enable-metrics` | Prometheus metrics |

## Offline Batch Inference
```python
from vllm import LLM
llm = LLM(model="model-name", tensor_parallel_size=2)
outputs = llm.generate(prompts, SamplingParams(temperature=0.7, max_tokens=256))
```
