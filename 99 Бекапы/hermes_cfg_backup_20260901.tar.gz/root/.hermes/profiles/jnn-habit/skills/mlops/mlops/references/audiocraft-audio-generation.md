# AudioCraft — Condensed Reference

Text-to-music (MusicGen) and text-to-sound (AudioGen).

## Install
```bash
pip install audiocraft
```

## Text-to-Music
```python
from audiocraft.models import MusicGen
model = MusicGen.get_pretrained('facebook/musicgen-medium')
model.set_generation_params(duration=30, temperature=1.0, cfg_coef=3.0)
wav = model.generate(["epic orchestral soundtrack"])
```

## Model Variants
| Model | Size | Use |
|-------|------|-----|
| `musicgen-small` | 300M | Quick |
| `musicgen-medium` | 1.5B | Balanced |
| `musicgen-large` | 3.3B | Best quality |
| `musicgen-melody` | 1.5B | Melody conditioning |
