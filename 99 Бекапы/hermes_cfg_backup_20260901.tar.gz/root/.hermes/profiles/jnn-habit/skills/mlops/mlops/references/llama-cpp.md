# llama.cpp + GGUF — Condensed Reference

Local GGUF inference on CPU/GPU.

## Install
```bash
brew install llama.cpp    # macOS/Linux
# Or: git clone https://github.com/ggml-org/llama.cpp && cmake -B build && cmake --build build
```

## Run from Hugging Face Hub
```bash
llama-server -hf bartowski/Llama-3.2-3B-Instruct-GGUF:Q8_0
llama-cli -hf bartowski/Llama-3.2-3B-Instruct-GGUF:Q8_0
```

## Python
```python
from llama_cpp import Llama
llm = Llama(model_path="./model-q4_k_m.gguf", n_ctx=4096, n_gpu_layers=35)
out = llm("What is ML?", max_tokens=256)
# Or from Hub: Llama.from_pretrained(repo_id="...", filename="*Q4_K_M.gguf")
```

## Quant Selection
- General chat: `Q4_K_M`
- Code/technical: `Q5_K_M` or `Q6_K`
- Tight RAM: `Q3_K_M`
- Always prefer the quant HF marks as compatible for your hardware
