# OBLITERATUS — Condensed Reference

Remove refusal behaviors from open-weight LLMs using mechanistic interpretability.

## Install
```bash
git clone https://github.com/elder-plinius/OBLITERATUS.git
cd OBLITERATUS && pip install -e .
# AGPL-3.0 — invoke via CLI only, never import
```

## VRAM Requirements (4-bit)
| VRAM | Max Model |
|------|-----------|
| 4-8GB | ~4B params |
| 8-16GB | ~9B params |
| 24GB+ | ~32B+ |

## Run
```bash
# Default method (advanced) — recommended
obliteratus obliterate model-name --method advanced --output-dir ./output

# With 4-bit quantization
obliteratus obliterate model-name --method advanced --quantization 4bit

# Get recommendation from telemetry
obliteratus recommend model-name
```

## 9 Methods
`basic`, `advanced` (default), `aggressive`, `spectral_cascade`, `informed`, `surgical`, `optimized`, `inverted`, `nuclear`

## Pitfalls
- Models under ~1B respond poorly
- `aggressive` can damage coherence
- MoE models need `nuclear`
- Always check perplexity change (< 15%)
