---
name: mlops
description: "ML operations: model serving, evaluation, inference, audio generation, image segmentation, experiment tracking."
version: 1.0.0
author: Hermes Agent (consolidated)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [MLOps, Model-Serving, LLM-Inference, Evaluation, Audio-Generation, Image-Segmentation, Experiment-Tracking]
    related_skills: [audiocraft-audio-generation, evaluating-llms-harness, huggingface-hub, llama-cpp, obliteratus, segment-anything-model, serving-llms-vllm, weights-and-biases]
---

# ML Operations

Machine learning operations: model serving, evaluation, inference optimization, audio/image generation, and experiment tracking.

## Skill Map

| Topic | Reference |
|-------|-----------|
| LLM serving (vLLM, high-throughput) | [references/serving-llms-vllm.md](references/serving-llms-vllm.md) |
| Local GGUF inference (llama.cpp) | [references/llama-cpp.md](references/llama-cpp.md) |
| LLM evaluation (lm-eval-harness) | [references/evaluating-llms-harness.md](references/evaluating-llms-harness.md) |
| HuggingFace Hub (hf CLI) | [references/huggingface-hub.md](references/huggingface-hub.md) |
| Audio generation (AudioCraft/MusicGen) | [references/audiocraft-audio-generation.md](references/audiocraft-audio-generation.md) |
| Image segmentation (SAM) | [references/segment-anything-model.md](references/segment-anything-model.md) |
| Experiment tracking (W&B) | [references/weights-and-biases.md](references/weights-and-biases.md) |
| LLM unalignment (OBLITERATUS) | [references/obliteratus.md](references/obliteratus.md) |

## Quick Reference: vLLM
```bash
pip install vllm
vllm serve meta-llama/Llama-3-8B-Instruct --gpu-memory-utilization 0.9
# OpenAI-compatible endpoint at http://localhost:8000/v1
```

## Quick Reference: llama.cpp
```bash
brew install llama.cpp
llama-server -hf bartowski/Llama-3.2-3B-Instruct-GGUF:Q8_0
# Or with Python: pip install llama-cpp-python
```

## Quick Reference: lm-eval-harness
```bash
pip install lm-eval
lm_eval --model hf --model_args pretrained=model-name --tasks mmlu,gsm8k --batch_size auto
```

## Quick Reference: AudioCraft
```bash
pip install audiocraft
# MusicGen: text-to-music, AudioGen: text-to-sound
```

## Quick Reference: SAM
```bash
pip install git+https://github.com/facebookresearch/segment-anything.git
# Zero-shot image segmentation via points, boxes, masks
```

## References
- `references/serving-llms-vllm.md` — vLLM serving, quantization, multi-GPU
- `references/llama-cpp.md` — GGUF models, quant selection, server mode
- `references/evaluating-llms-harness.md` — 60+ benchmarks, vLLM backend
- `references/huggingface-hub.md` — hf CLI, repos, datasets, Spaces
- `references/audiocraft-audio-generation.md` — MusicGen, AudioGen, EnCodec
- `references/segment-anything-model.md` — SAM variants, prompts, auto mask generation
- `references/weights-and-biases.md` — Experiment tracking, sweeps, artifacts
- `references/obliteratus.md` — 9 CLI methods, direction extraction, verification
