# Segment Anything (SAM) — Condensed Reference

Zero-shot image segmentation via points, boxes, masks.

## Install
```bash
pip install git+https://github.com/facebookresearch/segment-anything.git
# Download checkpoint: sam_vit_h_4b8939.pth (2.4GB), sam_vit_l (1.2GB), sam_vit_b (375MB)
```

## Usage
```python
from segment_anything import sam_model_registry, SamPredictor
sam = sam_model_registry["vit_h"](checkpoint="sam_vit_h_4b8939.pth")
predictor = SamPredictor(sam)
predictor.set_image(image)
masks, scores, logits = predictor.predict(
    point_coords=np.array([[500, 375]]),
    point_labels=np.array([1]),
    multimask_output=True
)
```

## Model Variants
| Model | Size | Speed |
|-------|------|-------|
| ViT-H | 2.4GB | Slowest, best |
| ViT-L | 1.2GB | Medium |
| ViT-B | 375MB | Fastest |
