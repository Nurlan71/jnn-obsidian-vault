# LLM Evaluation (lm-eval-harness) — Condensed Reference

60+ academic benchmarks (MMLU, GSM8K, HumanEval, HellaSwag, TruthfulQA).

## Install & Run
```bash
pip install lm-eval
lm_eval --model hf --model_args pretrained=model-name --tasks mmlu,gsm8k,hellaswag --batch_size auto
lm_eval --tasks list  # View all tasks
```

## Common Benchmarks
- **MMLU**: 57 subjects, multiple choice (use `--tasks mmlu_stem` for subset)
- **GSM8K**: Grade school math
- **HumanEval**: Python code generation
- **HellaSwag**: Common sense reasoning

## vLLM Backend (5-10x faster)
```bash
lm_eval --model vllm --model_args pretrained=model-name,tensor_parallel_size=2 --tasks mmlu
```

## Speed Tips
- Use vLLM backend
- `--num_fewshot 0` for quick checks
- `--batch_size auto`
