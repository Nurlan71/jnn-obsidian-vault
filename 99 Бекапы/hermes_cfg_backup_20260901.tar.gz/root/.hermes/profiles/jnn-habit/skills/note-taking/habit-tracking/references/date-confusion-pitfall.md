# Date Confusion Pitfall — Morning vs Evening Weight

**Incident:** 2026-06-27. Agent assigned a morning weight (98.9 кг) to the previous day's row, causing the evening weight (99.6 кг on June 26) to appear as a 0.0 delta instead of the actual +0.7 kg from food/water absorption.

## What happened

1. User reported evening data for June 26 (dinner дымдам + steps 15,390) → logged correctly to row 26
2. User then reported "утром вес 98.9" for June 27 → agent wrote this as if it were the morning weight for June 26
3. This created confusion: was 98.9 the morning of 26th or 27th?
4. User called it out: "Ты весы и шаги где записываешь? Почему путаница с датами?"

## Root cause

Agent treated "утром вес X" as belonging to the most recently discussed day, without checking:
- Is this a NEW day's morning data, or a correction to yesterday's morning?
- Does the system date match what the user implies?

## Rule

- **"Утро" = beginning of CURRENT day** (the day the user is reporting on)
- **"Вес" without qualifier = evening/current measurement for CURRENT day**
- When in doubt: ask "за сегодня или за вчера?" — but prefer checking system date first
- Morning weight and evening weight for the same date coexist in the same row

## File location

All weight data: `/opt/data/obsidian-vault/Habit/weight-tracking.md`

---

## Multi-Day Correction Pattern — User Fixes Already-Logged Data

**Incident:** 2026-06-27. User corrected agent: "25 июня 99.6 было. И в 26 июня тоже 99.6 кг. Сегодня 27 июня утром 98.9 кг."

### What happened
1. Agent had logged June 25 as having no weight (—) and June 26 as 99.6 with wrong delta
2. User provided a batch correction covering 3 days at once
3. Agent's first attempt made things worse by overwriting incorrectly

### Rules for batch corrections
- **When user says multiple days at once**: process each day separately, in chronological order
- **Always show the full correction plan** before applying: "Исправлю: 25-е → 99.6, 26-е → 99.6, 27-е → 98.9. Верно?"
- **After applying, re-read the file** and show the corrected table snippet for user to verify
- **Never assume a missing entry means 0.0** — missing means unknown, use "—" until confirmed
- **If user contradicts already-logged data**: trust the user, correct silently, then confirm

### User behavior pattern
- Nurlan reports data in portions throughout the day (morning weight, afternoon steps, evening food)
- He also does batch corrections when he notices inconsistencies
- He values accuracy — will call out errors directly and expects immediate correction
- He asks "где ты записываешь?" when confused — be ready to show file paths and table state

---

## Duplicate Entry Pattern — Same Date Appears Twice

**Incident:** 2026-06-28. Agent created TWO rows for June 28 in weight-tracking.md by writing the morning weight as a new row instead of recognizing it belonged to the same date that was just logged from a different data point.

### What happened
1. User reported evening data for June 27 (dinner + steps 18,988) → logged to row 27
2. User then reported "утром вес 98.8" for June 28 → agent created a NEW row for 28
3. Later, user's data implied June 28 already had an entry → duplicate detected
4. Patch tool returned "Found 2 matches" error, requiring `execute_code` with broader context to resolve

### Root cause
Agent treated every new data point as requiring a new row, without checking if the date already existed.

### Rules
- **ONE row per date** — always. Morning and evening data coexist in the same row.
- Before writing a new row: `read_file` the table and grep for the date
- If the date exists → patch the existing row, don't create a new one
- If patch returns "Found N matches" → you have duplicates. Use `execute_code` with unique context (surrounding rows) to target the right one
- After any write, re-read to verify no duplicates remain
- When adding steps/nutrition to an existing date, use the "Примечание" column or sub-entry section
