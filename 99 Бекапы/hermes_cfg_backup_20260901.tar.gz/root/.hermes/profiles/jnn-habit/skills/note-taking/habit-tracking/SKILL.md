---
name: habit-tracking
description: "Habit tracking and health metrics logging for daily weight, steps, nutrition, and mental health religious practice. Dual-write to Obsidian vault and workspace-habit."
---

# Habit Tracking — Health Metrics Logger

Use this skill when logging daily health metrics for Nurlan: weight, steps, nutrition, namaz, and other habits.

## Trigger conditions

- User mentions weight ("вес"), steps ("шаги"), food/meal ("обед", "ужин", "кушал"), namaz/намаз
- User asks for daily summary or progress report
- Routine morning/evening check-in

## Files & paths

| Data | Primary file | Backup file |
|------|-------------|-------------|
| Weight | `/opt/data/obsidian-vault/Habit/weight-tracking.md` | `/opt/data/workspace-habit/metrics_history.md` |
| Steps | `/opt/data/workspace-habit/metrics_history.md` | — |
| Nutrition | `/opt/data/obsidian-vault/Habit/weight-tracking.md` → section "Питание DD.MM" | `/opt/data/workspace-habit/metrics_history.md` → "Примечание" column |

**Always write to BOTH locations.** Re-read before patching if "modified since last read" warning appears.

## Weight table format (weight-tracking.md)

```
| Дата | Вес (кг) | Дельта | Примечание |
|------|----------|--------|------------|
| YYYY-MM-DD | XXX.X | ±X.X | <note> |
```

- Дельта = difference from previous measurement
- Use negative sign for loss (good!), positive for gain
- Flag records with ⚠️ if delta seems unrealistic (> 1 kg in one day)

## Weight table format (metrics_history.md)

```
| Дата | Вес (кг) | Примечание |
|------|----------|------------|
| YYYY-MM-DD | XXX.X | <note> |
```

## Steps table format

```
| Дата | Шаги | Цель |
|------|------|------|
| YYYY-MM-DD | X,XXX | 7,000 |
```

Goal is 7,000 steps/day. Mark entries with 🔥 when target exceeded.

## Nutrition logging format

```
## Питание DD.MM
- 🍽 Обед: <food> (<weight> г) ≈ <calories> ккал
- 🍽 Ужин: <food> (<weight> г) ≈ <calories> ккал
- 🕌 Намаз: 5 раз ✅
- 🚶 Шаги: <count>
```

Format DD.MM (day.month, no year needed in section header since year is implicit).

## Date rules (CRITICAL)

0. **MANDATORY: run `date` immediately BEFORE every single metrics write** (weight, steps, food — any data). Never rely on a date captured earlier in the session — user messages often span midnight. A wrong date corrupts the log (learned 2026-08-01: user reported weight "today" but session had started on 31.07; recorded 01.08 data under 31.07. User explicitly demanded: "Каждый раз, перед записью метрик, проверь системное время, только после этого сохраняй данные").
1. **Always verify via `date` tool first** — never guess
2. "Сегодня" = system date
3. "Вчера" = system date - 1 day
4. "Позавчера" = system date - 2 days
5. User-sourced dates: verify against system date; if mismatch, ask for clarification
6. **Do not backfill dates** without explicit "which day?" confirmation

### Midnight rollover in long sessions — PITFALL (learned 2026-08-01)

**Messages in one chat session can span midnight.** The system date captured at session start goes stale — "сегодня" for a message received hours later may be the NEXT day.

- ALWAYS re-run `date` before each write batch; re-derive "сегодня"/"вчера" from the fresh timestamp. Never trust a date captured earlier in the same session.
- Symptom of the failure: user says «Не путай, сегодня уже 1 августа» after the agent logged the morning weight under yesterday's date. Fix cost a full correction cycle (revert wrong row, add new row, fix goals section).
- When a weight/step report arrives and there's any doubt which day it refers to, state the date you're about to write and show the table snippet — the user confirms or corrects quickly.

### Morning vs Evening weight — PITFALL (learned 2026-06-27)

**Weight data has TWO entries per day: morning (fasting) and evening (post-meal).** They belong to the SAME date row.

- When user says "утром вес X" → this is the **morning weight for TODAY**
- When user says "вес X" (evening context) → this is the **evening weight for TODAY**
- Morning weight goes in the table as the primary entry for that date
- Evening weight (if different) can be noted in the "Примечание" column or as a sub-entry

**NEVER shift morning data to the previous day's row.** If user says "утром 98.9" on June 27, it belongs to June 27 — NOT June 26.

**Sequence pattern to watch for:**
1. Evening day N: user reports dinner + steps → log to row N
2. Morning day N+1: user reports fasting weight → this is the morning weight for row N+1
3. The delta between evening N and morning N+1 shows overnight water/food processing

If you already logged an evening weight and then receive a morning weight that is LOWER, do NOT overwrite — they are different measurements (fasting vs fed). Add the morning weight as the official weight for the new day.

## Health Symptoms Logging

When user reports symptoms (pain, belching, heartburn, etc.), log them in the weight-tracking.md file under a section for that date or a dedicated symptoms section.

**Format:**
```
## Симптомы (запись от DD.MM)
- 📍 *Боль:* <location>, <character>, <triggers>
- 💨 *Отрыжка:* <when it occurs>, <character>
- 🔬 *Версии:* <possible diagnoses>
- ⚠️ *Рекомендация:* <what to do>
```

**Key correlations to note:**
- Belching only after eating (not during fasting) → suggests acid-related cause (gastritis/GERB)
- Pain that improves with fasting → acid-related
- Pain that worsens with fasting → may be ulcer (needs FGDS)
- Always note the temporal relationship: symptom → food, symptom → fasting

## Known context

- User is Muslim, does NOT eat pork (beef, lamb, chicken only)
- Preferred foods: плов, лагман, шорпо, голубцы, бульон, лепешка
- Goal weight: 80 kg (from 101 kg starting point, 06.05.2026)
- Calorie target: ~1500-1800 kcal/day for weight loss
- Overeating at celebrations (weddings) is normal — do not shame, just note and move on

## Response style

- **Brevity**: short entries, celebrate losses gently, note gains without judgment
- **Motivating but direct**: praise effort, gently note gaps
- **Strengths-based**: highlight streaks, record personal bests
- **For mismatches**: when user logs a day that differs from assumed date, correct the table silently, then deliver the actual entry
- **Handle contradictory data**: if user says something already in the table but with different values, ask which is correct before overwriting
- **When user corrects already-logged data**: trust the user, apply corrections silently, re-read the file, and show the corrected table snippet for verification
- **Batch corrections**: when user provides multiple days of data at once, process chronologically, show the plan before applying, then verify after

## Cross-agent communication (JNN)

When you need an action from another agent — most often **Навигатор** (e.g. GitHub access, permissions, cross-department data) — do ALL THREE for reliability (learned 2026-08-01):

1. **Event bus** — emit a request event:
   `python3 /root/.hermes/skills/jnn_emit_event.py "HABIT" "request_access" '{"to": "navigator", "what": "github_access", "detail": "..."}'`
2. **Request file** — write the full description to `/opt/shared/requests/YYYY-MM-DD_<agent>_<topic>.md` (folder created 2026-08-01; it's the shared inbox pattern)
3. **Shared log** — append via `/opt/shared/agent-logs/log.sh "HABIT" "TASK_DONE" "Запрос: ..."` (Navigator reads all-agents.log for his morning/evening briefings)

Don't expect an instant reply — Navigator acts on his briefing cycle or when Нурлан pings him in the common chat. Tell the user how to speed it up. When the user then says "проверь доступ" — verify with `git ls-remote` before pushing.

Details: `references/cross-agent-communication.md`.

## Cron mode (scheduled reports)

When running as a cron job (no user present):

- **Trigger:** every day at 08:00 (morning check-in) and 20:00 (evening report)
- **No clarifying questions** — make reasonable decisions autonomously
- **No separate confirmation** — the delivered report IS the confirmation
- **Report structure** (~150 words, delivered automatically):
  1. ✅/❌ status per habit: weight, steps (target 7000), English (20 min), nutrition
  2. Celebrate wins (new minima, streaks, records)
  3. Gently note gaps — one line per missing habit
  4. Short motivational closing
- **Partial data (some habits logged, others missing):** report ✅ for what's logged, ❌ for what's missing. Do not conflate — weight logged ≠ steps logged. Show each habit separately.
- **If no data at all for today:** report that briefly and ask user to send metrics
- **Table desync check:** before the report, compare the LAST row of the weight table against the LATEST notes section header (## DD.MM). If the table has no entry for today but the notes do, flag in the report: `📋 Вес в заметках есть, в таблице — нет (синхронизирую при следующей записи)`. If gap exceeds 3 days, note it gently.
- **Goals section stale check:** read `## Цели` in weight-tracking.md. If `Текущий:` date is more than 3 days old and newer weight data exists in notes/metrics_history, include a line: `📋 Раздел целей не обновлён с <date> (текущий по данным: <latest_weight> кг)`.
- **Format:** emoji-driven, markdown-light, concise bullet points
- **Git push:** attempt always; if auth fails, commit is saved locally — report the failure briefly

## Workflow sequence (CRITICAL — do not skip steps)

Every time user provides new metric data (weight, steps, food):

1. **READ BOTH files first** — check for existing entries for that date.
   - Before writing, verify the target date does NOT already exist in each file's table.
   - If a date already exists in one file but not the other → sync it (another agent may have only written to one location).

2. **PATCH weight-tracking.md** (table + nutrition sections + goals):
   - **Table:** add new row with date, weight, delta (from previous row), note
   - **Goals section (`## Цели`):** update BOTH lines:
     - `- Текущий: **XX.X кг (YYYY-MM-DD)**` → set to new weight and today's date
     - `- Прогресс: **−X.X кг от старта**` → recalculate: start_weight (101.0) − current_weight
   - **Nutrition section:** log food under `## DD.MM (день недели)`

3. **PATCH metrics_history.md** (weight table + steps table):
   - Weight table: add/update date row (format: `| YYYY-MM-DD | XX.X | Примечание |`)
   - Steps table: add/update date row if steps data provided

4. **DUAL-WRITE VERIFY** — check that BOTH files have the new entry:
   ```bash
   grep "YYYY-MM-DD" /opt/data/obsidian-vault/Habit/weight-tracking.md | head -3
   grep "YYYY-MM-DD" /opt/data/workspace-habit/metrics_history.md | head -3
   ```
   If only one file has the entry, manually add to the other.

5. **EVENT BUS** — log the update:
   ```bash
   python3 /root/.hermes/skills/jnn_emit_event.py "HABIT" "metrics_logged" '{"date": "YYYY-MM-DD", "weight": XX.X, "steps": XXXXX, "new_minimum": true/false}'
   ```

6. **GIT PUSH** — push to GitHub:
   ```bash
   cd /opt/data/obsidian-vault
   git add -A
   git commit -m "Habit: <brief summary of changes>"
   git pull --rebase origin main   # ALWAYS pull --rebase first (remote may be ahead)
   git push origin main
   ```
   **If push is rejected (remote ahead):** `git pull --rebase origin main` then `git push origin main` — this is expected when another agent or device pushed changes.

   **Or use the script:** `bash /root/.hermes/profiles/jnn-habit/skills/note-taking/habit-tracking/scripts/git-push-metrics.sh` — already handles pull+rebase on failure.

   **PITFALL: metrics_history.md is NOT in git.** `/opt/data/workspace-habit/` is not a git repository, and the script's `git add ../workspace-habit/metrics_history.md` fails silently (path is outside the repo tree). Steps-only updates therefore print `No changes to push` — that is EXPECTED, not an error; don't chase it. Git push covers only `weight-tracking.md` (verified 2026-07-31).

7. **CONFIRM/DELIVER** — brief summary of what was recorded:
   - **Interactive mode:** send the summary directly to the user
   - **Cron mode (daily report):** the scheduled report IS the confirmation — format it as the report itself, don't send a separate confirmation

**Pitfall:** Git push rejected (remote ahead) → `git pull --rebase origin main` then push again.
**Pitfall:** Git push rejected (auth failure) → token may have expired. Commit is saved locally; notify user separately.
**Check access first:** after an auth failure, test with `timeout 20 git ls-remote origin main` — if it returns a hash, access is OK now and the failure was transient; just rebase+push. If it still fails, request access from Навигатор (see Cross-agent communication section + `references/cross-agent-communication.md`). In JNN the Navigator opens GitHub access for agents — the user expects us to ask him (verified 2026-08-01: requested access, next day `git ls-remote` worked, push succeeded after `git pull --rebase`).

**User explicitly confirmed (2026-07-11):** expects GitHub push with EVERY metrics write. Question "в обсидиан в гитхабе тоже обновляешь метрики?" means this is NOT optional. Do not skip git push.

## ⚠️ PATCH + Markdown Table Pitfall (learned 2026-07-11, updated 2026-07-12)

**patch tool regularly corrupts markdown tables** — when `old_string`/`new_string` contain pipe characters `|`, the tool's fuzzy matching inserts extra pipes, creating garbage rows.

**Corruption patterns observed:**
| Pattern | Example | Cause |
|---------|---------|-------|
| Triple pipes | `\|\|\| 2026-07-11 \|` | patch adds `\|` to existing `\|\|` |
| Double-pipe at start | `\|\| 2026-07-11 \|` while rest of table uses `\|` | patch inserts `\|` at start of new row |
| Sibling row corrupted | The row ABOVE or BELOW the target gets mangled instead | fuzzy match targets wrong line |
| "Found N matches" error | Error when the date exists in multiple rows (duplicates) | patch sees both rows |

**Root cause:** patch's fuzzy matching interacts badly with markdown table syntax, especially when rows are visually similar (same date pattern, same pipe structure). Each patch call risks damaging neighboring rows.

**Prevention (preferred methods, in order):**

1. **Best: use sed for new table rows** — avoid patch entirely for append operations:
   ```bash
   # Add a new row after the last dated row (line N)
   sed -i 'N a\|\| YYYY-MM-DD | XXX.X | ±X.X | Примечание |' /path/to/file
   ```
   Easier: use `echo` and append:
   ```bash
   echo "\|\| $(date +%F) | 97.1 | -0.5 | Утро, воскресенье |" >> /path/to/file
   ```
   Then `sed -i` to insert before the section header.

2. **If using patch: include MAXIMAL context** — target the row ABOVE AND BELOW:
   ```
   old_string: "|\| 2026-07-10 | 97.5 | ... |\n|| 2026-07-11 | 97.6 | ... |\n\n## Питание"
   new_string: "|\| 2026-07-10 | ... |\n|| 2026-07-11 | 97.6 | ... |\n|| 2026-07-12 | 97.1 | ... |\n\n## Питание"
   ```
   Include the section header after the table so the match is globally unique.

3. **After EVERY table patch** → immediately read the affected region (offset=target_row-2, limit=5) to check for corruption.

**Rescue (when corruption already happened):**
```bash
# Fix triple pipes → single pipe (exact tested command)
sed -i 's/^|||/|/' /opt/data/obsidian-vault/Habit/weight-tracking.md

# Fix double pipes at line start (exact tested command)
sed -i '/| 2026-07-1[012] |/s/^|| /| /' /opt/data/obsidian-vault/Habit/weight-tracking.md

# Fix double pipes for a specific date range
sed -i 's/^|| 2026-07-11/| 2026-07-11/' /opt/data/obsidian-vault/Habit/weight-tracking.md

# Verify after fix
read_file --path /opt/data/obsidian-vault/Habit/weight-tracking.md --offset 48 --limit 10
```
**Always verify after sed** — read back the affected lines.

**Last resort:** if both files are corrupted the same way, run sed on both:
```bash
for f in /opt/data/obsidian-vault/Habit/weight-tracking.md /opt/data/workspace-habit/metrics_history.md; do
  sed -i 's/^|||/|/' "$f"
  sed -i '/2026-07-/s/^|| /| /' "$f"
done
```

## Duplicate Entry Cleanup (CRITICAL)

Before patching any date, **always check if that date already exists in the table.** If patch returns "Found N matches" error, you have duplicates — use `read_file` the full file first, then use a more unique `old_string` that includes surrounding context to target the specific duplicate.

**Common triggers:**
- User re-reports data for a date that already has an entry (correction or addition of new info like steps)
- Agent accidentally writes the same date as a new row when it should have been a patch to the existing row
- Morning weight and evening weight both create separate rows instead of coexisting in one row

**PITFALL (metrics_history.md): dates legitimately repeat across sections.** The same date appears in BOTH the `## Вес` table AND the `## Шаги` table (e.g. `2026-07-28` is a weight row AND a steps row). When appending steps, scope the duplicate check to the steps section only:
```python
text = open(path).read()
steps_section = text.split("## Шаги")[1].split("## Английский")[0]
assert "YYYY-MM-DD" not in steps_section, "steps already exist"
```
A naive check over the whole file raises a false "already exists" on the weight row (hit 2026-07-31). Same applies to weight appends: check only the `## Вес` section, not the whole file.

**Rule: ONE ROW per date.** Multiple measurements (morning/evening) go in the same row's "Примечание" column.

If the same date appears twice in a table, ask user which entry is correct. If patch "modified since last read" warning triggers, always re-read the full file before patching.

**See also:** `references/date-confusion-pitfall.md` for the duplicate-entry pattern.

## ⚠️ Notes-Before-Table Pattern (learned 2026-07-25)

**The weight-tracking.md file has TWO data locations:**
1. The **main table** (`| Дата | Вес | Дельта | Примечание |`) — the canonical daily log
2. The **notes section** (`## DD.MM (день недели)`) — quick daily summaries

**Common desync pattern:** Notes get updated (especially via cron or quick log from user) but the table doesn't. This means:
- Table row is missing → goals section `Текущий:` stays stale
- Delta column can't be computed automatically
- Progress calculation becomes inaccurate

**Detection during cron/read operations:**
```bash
# Get last table row date
grep '| 2026-' /opt/data/obsidian-vault/Habit/weight-tracking.md | grep -v '|---' | tail -1

# Get latest notes section header
grep '^## [0-9]' /opt/data/obsidian-vault/Habit/weight-tracking.md | tail -1

# Compare — if notes date > table date, table is behind
```

**When to sync (during cron report):** If the gap is 1–2 days, sync immediately: compute deltas, add rows, update goals. If gap exceeds 3 days, flag in the report and offer to batch-sync rather than syncing silently (risk of accumulating errors or overwriting user corrections). For cron: flag is sufficient — user can request the batch sync.

**Interactive mode: sync ANY gap immediately (even >3 days).** Compute deltas from the notes, insert rows, update goals, then mention the sync in your reply. Verified 2026-07-31: silently synced 17–28.07 (10-day gap) while logging new weight — user was fine with it and expects the table current.

**Why this happens regularly:** Another agent (or user's phone/another device) may write the notes section directly without touching the table. The table has stricter formatting (delta math, pipe alignment) so it gets deferred. Always check both locations when reading weight data.

## Progress calculation

When user asks for progress report:
- Total days from start (06.05)
- Total weight lost from start (101.0 → current)
- Consecutive days with steps ≥ 7,000
- Current streak (days with logged data in either file)
