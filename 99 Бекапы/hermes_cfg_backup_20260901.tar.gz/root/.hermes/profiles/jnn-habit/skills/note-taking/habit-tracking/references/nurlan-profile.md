# Nurlan — Health Profile & Goals

## Personal
- DOB: 2 January 1971 (55 years old as of May 2026)
- Height: 172 cm
- Waist: 118 cm
- Allergies: none

## Goals
- **Weight:** 80 kg (from 101.0 kg start on 06.05.2026) → −21 kg target
- **Steps:** 7,000+/day
- **English:** 20 min practice/day
- **Namaz:** 5 times/day (mandatory)
- **Calories:** ~1500-1800 kcal/day for weight loss

## Dietary
- Muslim — NO pork (beef, lamb, chicken only)
- Favorite foods: плов, лагман, куурдак, манты, шорпо, чучпара, пельмени, оромо, голубцы
- Wife Alya cooks dinner
- Tendency to overeat at celebrations (weddings, etc.) — handle with understanding

## GI Symptoms (noted 2026-06-28)
- **Persistent pain** in epigastric region (stomach + duodenum area)
- **Belching** occurs ONLY after eating, almost absent during fasting
- **Pattern:** symptoms worsen with food, improve with fasting → suggests acid-related cause
- **Possible diagnoses:** gastritis with high acidity, GERB (reflux), functional dyspepsia, peptic ulcer
- **Action needed:** FGDS (gastroscopy) + Helicobacter pylori test
- **Dietary adjustments:** avoid spicy, smoked, acidic, fried foods; small portions; don't lie down 1-2h after eating
- **Note:** Fasting walking may be beneficial for GI rest — belching stops during fasting

## Baseline metrics
- Start weight: 101.0 kg (06.05.2026, from dietitian)
- BMI: 34.2 (obesity class I)
- 12-day progress (to 17.06): −1.3 kg

## Reminders schedule (BKT UTC+6)
- 08:00 morning briefing
- 10:00 steps reminder
- 12:00 lunch
- 14:00 steps + english
- 15:00 snack
- 17:00 walk
- 19:00 english
- 21:00 psychologist
- 22:00 sleep

## Team context
- Wife: Alya (finance, cooks)
- Team: Timur (sales/marketing), Aigerim (marketing), Ruslan (production)
- Business: JNN Factory — women's clothing, wholesale on Wildberries
