# Cross-Agent Communication — JNN

How to request an action from another agent (Навигатор, Финдир, и т.д.) from an agent profile.

## Channels (use ALL THREE for reliability)

1. **Event bus** — `/root/.hermes/Obsidian/JNN-Vault/bus/events.jsonl`
   ```bash
   python3 /root/.hermes/skills/jnn_emit_event.py "HABIT" "request_access" '{"to": "navigator", "what": "github_access", "repo": "Nurlan71/jnn-obsidian-vault", "detail": "..."}'
   ```
   Events are JSONL, readable via `jnn_read_events()` in the same module. Other agents poll this bus.

2. **Request file** — shared inbox folder: `/opt/shared/requests/YYYY-MM-DD_<agent>_<topic>.md`
   Write a self-contained description: who asks, what's needed, exact paths/repos, why (user context).

3. **Shared log** — `/opt/shared/agent-logs/all-agents.log` via:
   ```bash
   /opt/shared/agent-logs/log.sh "HABIT" "TASK_DONE" "Запрос Навигатору: ..."
   ```
   Навигатор reads logs when assembling his morning (04:00) / evening briefings — this is the most likely channel he actually sees.

## Timing expectations

- Navigator does NOT reply instantly. He reacts on his briefing cycle, or when Нурлан pings him in the common Telegram chat.
- To speed up: tell the user to ping the Navigator directly («Навигатор, открой GitHub доступ для Хабита»).
- When the user reports back "проверь доступ" — verify before acting: `timeout 20 git ls-remote origin main` (returns a hash = access works).

## Verified case (2026-08-01)

- Problem: `git push` to Nurlan71/jnn-obsidian-vault → `Invalid username or token. Password authentication is not supported`.
- Action: emitted `request_access` event + wrote `/opt/shared/requests/2026-08-01_habit_github_access.md` + logged to all-agents.log.
- Result: on the user's next message, `git ls-remote` already returned a hash → access was opened by Navigator.
- Push after remote-ahead rejection: `git pull --rebase origin main` then `git push origin main` (rebase, not merge — keeps history linear).

## Related

- Agent profiles live at `/root/.hermes/profiles/jnn-*` (jnn-navigator, jnn-habit, jnn-finance, jnn-sales, ...). Do NOT modify another profile's files unless explicitly directed.
- Navigator's cron jobs (jnn-navigator/cron/jobs.json) are what make him read logs — use the log channel for anything time-sensitive.
