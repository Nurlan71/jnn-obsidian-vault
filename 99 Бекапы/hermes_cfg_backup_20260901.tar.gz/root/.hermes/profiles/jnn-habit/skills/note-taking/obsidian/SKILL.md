---
name: obsidian
description: Read, search, create, and edit notes in the Obsidian vault.
platforms: [linux, macos, windows]
---

# Obsidian Vault

Use this skill for filesystem-first Obsidian vault work: reading notes, listing notes, searching note files, creating notes, appending content, and adding wikilinks.

## Vault path

Use a known or resolved vault path before calling file tools.

The documented vault-path convention is the `OBSIDIAN_VAULT_PATH` environment variable, for example from `~/.hermes/.env`. If it is unset, use `~/Documents/Obsidian Vault`.

**JNN/Habit-Control vault:** On JNN production servers, the Obsidian vault is at `/opt/data/obsidian-vault/`. Always check this path first before creating any new metric or tracking files.

File tools do not expand shell variables. Do not pass paths containing `$OBSIDIAN_VAULT_PATH` to `read_file`, `write_file`, `patch`, or `search_files`; resolve the vault path first and pass a concrete absolute path. Vault paths may contain spaces, which is another reason to prefer file tools over shell commands.

If the vault path is unknown, `terminal` is acceptable for resolving `OBSIDIAN_VAULT_PATH` or checking whether the fallback path exists. Once the path is known, switch back to file tools.

## JNN metric storage convention

When recording or updating health/lifecycle metrics (weight, steps, nutrition, etc.):

1. **Always search first** — check `/opt/data/obsidian-vault/Habit/` and `/opt/data/workspace-habit/` before creating any new file.
2. **Do not create duplicate tracking files** — if a file like `weight-tracking.md` or `metrics_history.md` already exists, append/update it rather than creating a new one.
3. If neither location has the expected file, ask the user where to store before creating.

### Dual-write pattern

Metrics are stored in TWO places for redundancy:
- **Obsidian vault:** `/opt/data/obsidian-vault/Habit/weight-tracking.md` (weight with deltas)
- **Workspace habit:** `/opt/data/workspace-habit/metrics_history.md` (weight, steps, english)

When recording weight or steps, **always write to both files**. If one file has been externally edited (detected by patch "modified since last read" warning), re-read it before patching.

### Date discipline (CRITICAL)

Never guess dates. Always verify the current date before writing any metric entry:
1. Run `date '+%d %B %Y %A'` to get the real current date
2. "Вчера" (yesterday) = current date minus 1 day
3. "Позавчера" (day before yesterday) = current date minus 2 days
4. When the user says a specific date (e.g., "сегодня 15 июня"), use that date — but verify it against system date to catch typos
5. **Never backfill dates** without explicit user confirmation — ask which day the data belongs to

### Duplicate cleanup

When patching tables, check for duplicate rows (same date appearing twice). If found, remove the duplicate and keep only the correct entry. External edits (e.g., from Obsidian sync) may introduce duplicates.

### Nutrition logging format

When logging meals, use this format in the metrics file:
```
## Питание DD.MM
- 🍽 Обед: <food> (<weight> г) ≈ <calories> ккал
- 🍽 Ужин: <food> (<weight> г) ≈ <calories> ккал
- 🕌 Намаз: 5 раз ✅
- 🚶 Шаги: <count>
```

User is Muslim — no pork. Preferred foods: плов, лагман, шорпо (with beef), голубцы.

## Read a note

Use `read_file` with the resolved absolute path to the note. Prefer this over `cat` because it provides line numbers and pagination.

## List notes

Use `search_files` with `target: "files"` and the resolved vault path. Prefer this over `find` or `ls`.

- To list all markdown notes, use `pattern: "*.md"` under the vault path.
- To list a subfolder, search under that subfolder's absolute path.

## Search

Use `search_files` for both filename and content searches. Prefer this over `grep`, `find`, or `ls`.

- For filenames, use `search_files` with `target: "files"` and a filename `pattern`.
- For note contents, use `search_files` with `target: "content"`, the content regex as `pattern`, and `file_glob: "*.md"` when you want to restrict matches to markdown notes.

## Create a note

Use `write_file` with the resolved absolute path and the full markdown content. Prefer this over shell heredocs or `echo` because it avoids shell quoting issues and returns structured results.

## Append to a note

Prefer a native file-tool workflow when it is not awkward:

- Read the target note with `read_file`.
- Use `patch` for an anchored append when there is stable context, such as adding a section after an existing heading or appending before a known trailing block.
- Use `write_file` when rewriting the whole note is clearer than constructing a fragile patch.

For an anchored append with `patch`, replace the anchor with the anchor plus the new content.

For a simple append with no stable context, `terminal` is acceptable if it is the clearest safe option.

## Targeted edits

Use `patch` for focused note changes when the current content gives you stable context. Prefer this over shell text rewriting.

## Wikilinks

Obsidian links notes with `[[Note Name]]` syntax. When creating notes, use these to link related content.
