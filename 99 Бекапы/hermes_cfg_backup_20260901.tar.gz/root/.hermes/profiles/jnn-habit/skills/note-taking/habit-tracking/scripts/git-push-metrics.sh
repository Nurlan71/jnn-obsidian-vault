#!/bin/bash
# Push metrics changes to GitHub
# Called after every write to weight-tracking.md or metrics_history.md

set -e
cd /opt/data/obsidian-vault

# Check if there are actually changes
if git diff --quiet; then
    echo "No changes to push"
    exit 0
fi

git add Habit/weight-tracking.md 2>/dev/null || true
git add ../workspace-habit/metrics_history.md 2>/dev/null || true

# Only commit if something was staged
if git diff --cached --quiet; then
    echo "Nothing staged"
    exit 0
fi

git commit -m "Habit: metrics update $(date '+%Y-%m-%d %H:%M')"
git push origin main 2>/dev/null || {
    echo "Push failed, trying pull+rebase first..."
    git pull --rebase origin main
    git push origin main
}
echo "✅ Pushed to GitHub"
