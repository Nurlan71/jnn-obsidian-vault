---
name: software-development
description: "Software development: debugging, TDD, code review, refactoring, spikes, skill authoring."
version: 1.0.0
author: Hermes Agent (consolidated)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Software-Development, Debugging, TDD, Code-Review, Refactoring, Testing]
    related_skills: [hermes-agent-skill-authoring, node-inspect-debugger, python-debugpy, simplify-code, spike, systematic-debugging, test-driven-development]
---

# Software Development

Development workflows: systematic debugging, test-driven development, code review, refactoring, spikes, and skill authoring.

## Skill Map

| Topic | Reference |
|-------|-----------|
| Systematic debugging (4-phase root cause) | [references/systematic-debugging.md](references/systematic-debugging.md) |
| Python debugging (pdb + debugpy) | [references/python-debugpy.md](references/python-debugpy.md) |
| Node.js debugging (--inspect + CDP) | [references/node-inspect-debugger.md](references/node-inspect-debugger.md) |
| Test-driven development (RED-GREEN-REFACTOR) | [references/test-driven-development.md](references/test-driven-development.md) |
| Code review & refactoring (3-agent parallel) | [references/simplify-code.md](references/simplify-code.md) |
| Spikes (throwaway experiments) | [references/spike.md](references/spike.md) |
| Skill authoring (SKILL.md format) | [references/hermes-agent-skill-authoring.md](references/hermes-agent-skill-authoring.md) |

## Quick Reference: Debugging
```bash
# Python
breakpoint()  # Add to source, run normally
python -m pdb script.py
python -m debugpy --listen 127.0.0.1:5678 --wait-for-client script.py

# Node.js
node inspect script.js
node --inspect-brk script.js
kill -SIGUSR1 <pid>  # Attach to running process
```

## Quick Reference: TDD
1. RED — Write failing test
2. Verify RED — Watch it fail
3. GREEN — Minimal code to pass
4. Verify GREEN — Watch it pass
5. REFACTOR — Clean up, keep tests green
6. Repeat

## Quick Reference: Spikes
1. Decompose into 2-5 feasibility questions
2. Research each approach
3. Build in `spikes/NNN-name/` directories
4. Verdict: VALIDATED | PARTIAL | INVALIDATED
5. Throw away after learning

## References
- `references/systematic-debugging.md` — 4-phase root cause process
- `references/python-debugpy.md` — pdb, debugpy, remote debugging
- `references/node-inspect-debugger.md` — --inspect, CDP, heap snapshots
- `references/test-driven-development.md` — RED-GREEN-REFACTOR enforcement
- `references/simplify-code.md` — 3-agent parallel review, auto-fix loop
- `references/spike.md` — Experiment workflow, comparison spikes
- `references/hermes-agent-skill-authoring.md` — SKILL.md format, validator
