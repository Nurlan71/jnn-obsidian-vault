# Simplify Code (3-Agent Review) — Condensed Reference

## When to Use
- "simplify" / "review my code" / "clean up my changes"
- After implementing a feature or bug fix

## Process
1. **Get diff**: `git diff` (or `git diff HEAD~1` for last commit)
2. **Launch 3 reviewers in parallel** via `delegate_task` batch mode:
   - **Reviewer 1 — Code Reuse**: Search for duplicated functionality
   - **Reviewer 2 — Code Quality**: Redundant state, parameter sprawl, copy-paste, leaky abstractions
   - **Reviewer 3 — Efficiency**: Unnecessary work, missed concurrency, hot-path bloat, TOCTOU
3. **Aggregate**: Merge findings, discard false positives, resolve conflicts
4. **Apply**: Use `patch`/`write_file` — scoped to diff only
5. **Verify**: Run targeted tests + linter

## Rules
- Give WHOLE diff to each reviewer (not fragments)
- Max 3 reviewers (more = more cost, conflicting suggestions)
- Apply ≠ rewrite — keep edits scoped to diff
- Respect project conventions (AGENTS.md, linter config)
