# Skill Authoring — Condensed Reference

## SKILL.md Format
```yaml
---
name: skill-name
description: "What this skill does."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [tag1, tag2]
---
```

## Structure
1. **Frontmatter** — YAML with name, description, version, tags
2. **Overview** — When to use, scope, what's inside
3. **Instructions** — Numbered steps, exact commands
4. **References** — Links to `references/` files
5. **Templates** — Starter files in `templates/`
6. **Scripts** — Runnable code in `scripts/`

## Best Practices
- Trigger conditions at the top
- Exact commands (copy-paste ready)
- Pitfalls section
- Verification steps
- Keep SKILL.md focused; put detail in `references/`
