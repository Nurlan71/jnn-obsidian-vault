# Node.js Debugging (--inspect + CDP) — Condensed Reference

## node inspect REPL
```bash
node inspect script.js           # Launch paused
node inspect -p <pid>           # Attach to running process
node --inspect-brk script.js    # Pause on first line
```

## REPL Commands
| Command | Action |
|---------|--------|
| `c` / `n` / `s` / `o` | continue / next / step / out |
| `sb('file.js', 42)` | set breakpoint |
| `bt` | backtrace |
| `repl` | drop into REPL in current scope |
| `exec expr` | evaluate expression |
| `.exit` | quit |

## Attaching to Running Process
```bash
kill -SIGUSR1 <pid>  # Enable inspector
node inspect -p <pid>
```

## CDP Scripting (chrome-remote-interface)
```bash
npm i -g chrome-remote-interface
node --inspect-brk=9229 target.js &
node /tmp/cdp-debug.js  # Custom CDP driver
```

## Heap Snapshots & CPU Profiles
Use CDP `HeapProfiler` and `Profiler` domains (see full reference for code).

## Pitfalls
- `--inspect` doesn't pause; use `--inspect-brk` for breakpoints before code runs
- Source maps: `node inspect` CLI doesn't follow them
- `--inspect=0.0.0.0` exposes arbitrary code execution — bind to 127.0.0.1
