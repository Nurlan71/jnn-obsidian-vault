# Systematic Debugging — Condensed Reference

## The Iron Law
NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST

## Four Phases

### Phase 1: Root Cause Investigation
1. Read error messages carefully (don't skip warnings)
2. Reproduce consistently (exact steps?)
3. Check recent changes (`git log --oneline -10`, `git diff`)
4. Gather evidence in multi-component systems (log at each boundary)
5. Trace data flow upstream to find source of bad value

### Phase 2: Pattern Analysis
1. Find working examples in the same codebase
2. Compare against references (read completely)
3. Identify differences between working and broken
4. Understand dependencies

### Phase 3: Hypothesis and Testing
1. Form single hypothesis: "I think X is root cause because Y"
2. Test minimally (one variable at a time)
3. Verify before continuing
4. If don't know — say so, ask for help

### Phase 4: Implementation
1. Create failing test case
2. Implement single fix (root cause, not symptom)
3. Verify fix + no regressions
4. If fix doesn't work: return to Phase 1
5. If 3+ fixes failed: question the architecture

## Red Flags (STOP and return to Phase 1)
- "Quick fix for now, investigate later"
- "Just try changing X and see if it works"
- "It's probably X, let me fix that"
- "One more fix attempt" (after 2+ failures)
