# Python Debugging (pdb + debugpy) — Condensed Reference

## pdb Quick Reference
| Command | Action |
|---------|--------|
| `n` / `s` / `r` | next / step into / return |
| `c` | continue |
| `l` / `ll` | list source |
| `w` | where (stack trace) |
| `p expr` / `pp expr` | print expression |
| `b file:line` | set breakpoint |
| `interact` | full Python REPL in scope |
| `q` | quit |

## Recipes

### Local breakpoint
```python
breakpoint()  # Add to source, run normally
# Don't forget to remove before committing!
```

### Launch under pdb
```bash
python -m pdb script.py
```

### Debug pytest
```bash
pytest tests/test_file.py::test_name --pdb -p no:xdist
```

### Post-mortem
```python
import pdb, sys
try: run()
except Exception: pdb.post_mortem(sys.exc_info()[2])
```

### Remote debug with debugpy
```bash
# In code: debugpy.listen(("127.0.0.1", 5678)); debugpy.wait_for_client()
# Or: python -m debugpy --listen 127.0.0.1:5678 --wait-for-client script.py
```

### remote-pdb (simpler alternative)
```bash
pip install remote-pdb
# In code: from remote_pdb import set_trace; set_trace(host="127.0.0.1", port=4444)
# Connect: nc 127.0.0.1 4444
```

## Pitfalls
- pdb under pytest-xdist silently does nothing — use `-p no:xdist`
- `PYTHONBREAKPOINT=0` disables all `breakpoint()` calls
- Attach to PID may fail on hardened kernels (ptrace_scope)
