# Test-Driven Development — Condensed Reference

## The Iron Law
NO PRODUCTION CODE WITHOUT A FAILING TEST FIRST

## Red-Green-Refactor Cycle

### RED — Write Failing Test
- One behavior per test
- Clear descriptive name
- Real code, not mocks (unless unavoidable)

### Verify RED — Watch It Fail
```bash
pytest tests/test_feature.py::test_name -v
```
Test must fail because feature is missing, not because of typos.

### GREEN — Minimal Code
Simplest code to pass. Hardcode, copy-paste, duplicate — we'll fix in REFACTOR.

### Verify GREEN — Watch It Pass
```bash
pytest tests/test_feature.py::test_name -v
pytest tests/ -q  # No regressions
```

### REFACTOR — Clean Up
Remove duplication, improve names, extract helpers. Keep tests green.

## Common Rationalizations (All Wrong)
- "Too simple to test" — Simple code breaks. Test takes 30 seconds.
- "I'll test after" — Tests passing immediately prove nothing.
- "Already manually tested" — Ad-hoc ≠ systematic. No record, can't re-run.
- "Deleting X hours is wasteful" — Sunk cost fallacy. Keeping unverified code is technical debt.
