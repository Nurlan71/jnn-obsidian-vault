# Spike (Throwaway Experiment) — Condensed Reference

## When to Use
- "let me try this" / "is this possible?" / "compare A vs B"
- Validate feasibility before committing to build

## Process
1. **Decompose** — 2-5 feasibility questions (Given/When/Then)
2. **Research** — Brief each spike, surface approaches, pick one
3. **Build** — One directory per spike: `spikes/001-name/`
4. **Verdict** — VALIDATED | PARTIAL | INVALIDATED
5. **Throw away** — Don't clean up for production

## Output
```
spikes/
├── 001-websocket-streaming/
│   ├── README.md  # Question, approach, verdict
│   └── main.py
├── 002a-approach-A/
└── 002b-approach-B/
```

## Comparison Spikes
Same question, different approaches (002a/002b). Build back-to-back, then head-to-head.
