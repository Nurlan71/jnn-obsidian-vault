---
name: coding-agents
description: "Delegate coding to AI agent CLIs: Claude Code, OpenAI Codex, OpenCode. Orchestrate autonomous coding workers via terminal."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Coding-Agent, Claude-Code, Codex, OpenCode, Autonomous, Delegation, PTY, Automation]
---

# Coding Agents — AI Agent CLI Orchestration

Delegate coding tasks to autonomous AI coding agents. Three supported backends:

| Agent | Provider | Install |
|-------|----------|---------|
| **Claude Code** | Anthropic | `npm install -g @anthropic-ai/claude-code` |
| **Codex** | OpenAI | `npm install -g @openai/codex` |
| **OpenCode** | Open-source | `npm i -g opencode-ai@latest` |

All three are TUI-based autonomous coding agents that can read files, write code, run shell commands, and manage git workflows.

## Choosing an Agent

- **Claude Code** — Best overall; rich feature set (MCP, hooks, subagents, CLAUDE.md memory)
- **Codex** — OpenAI's agent; good for OpenAI ecosystem integration
- **OpenCode** — Provider-agnostic, open-source; works with any model via OpenRouter etc.

## Common Patterns

### One-Shot Tasks (Print Mode)

Preferred for bounded tasks. No PTY needed.

```bash
# Claude Code
claude -p "Add error handling to all API calls in src/" --allowedTools "Read,Edit" --max-turns 10

# Codex
codex exec "Add dark mode toggle to settings"

# OpenCode
opencode run "Add retry logic to API calls and update tests"
```

### Interactive Sessions (Background + PTY)

For multi-turn iterative work:

```bash
# Claude Code
tmux new-session -d -s agent-work -x 140 -y 40
tmux send-keys -t agent-work 'cd /project && claude' Enter
sleep 5 && tmux send-keys -t agent-work 'Refactor the auth module' Enter
tmux capture-pane -t agent-work -p -S -50  # monitor

# Codex
codex exec --full-auto "Refactor the auth module"  # background + pty

# OpenCode
opencode  # background + pty, then process(action="submit", data="Implement OAuth flow")
```

### Parallel Work

Run multiple independent tasks simultaneously:

```bash
# Claude Code
claude -p "Fix auth bug" --allowedTools "Read,Edit" --max-turns 10 &
claude -p "Write API tests" --allowedTools "Read,Write,Bash" --max-turns 15 &

# Codex
codex exec --full-auto "Fix issue #78" &
codex exec --full-auto "Add parser tests" &

# OpenCode
opencode run "Fix issue #101" &
opencode run "Add regression tests" &
```

## Claude Code Deep Dive

### Print Mode (`-p`)
- One-shot, non-interactive, exits when done
- `--max-turns N` — limit agentic loops (prevents runaway)
- `--allowedTools "Read,Edit,Bash"` — restrict capabilities
- `--output-format json` — structured output with `session_id`, `total_cost_usd`
- `--model sonnet|opus|haiku` — model selection

### Interactive Mode
- Requires tmux for orchestration
- Dialogs: workspace trust (Enter), permissions bypass (Down+Enter)
- Slash commands: `/compact`, `/cost`, `/review`, `/plan`, `/model`

### Key Flags
| Flag | Effect |
|------|--------|
| `-p` | Non-interactive one-shot |
| `--dangerously-skip-permissions` | Auto-approve all tool use |
| `--max-turns N` | Limit agentic loops |
| `--max-budget-usd N` | Cap API spend |
| `--allowedTools` | Whitelist tools |
| `--output-format json` | Structured JSON output |
| `--bare` | Skip hooks/plugins/MCP (fastest) |

## Codex Deep Dive

### Key Flags
| Flag | Effect |
|------|--------|
| `exec "prompt"` | One-shot execution |
| `--full-auto` | Auto-approve changes in sandbox |
| `--yolo` | No sandbox, no approvals |
| `--sandbox danger-full-access` | No bubblewrap (for service contexts) |

### PR Reviews
```bash
REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW
cd $REVIEW && gh pr checkout 42 && codex review --base origin/main
```

### Parallel Issue Fixing
```bash
git worktree add -b fix/issue-78 /tmp/issue-78 main
codex exec --yolo "Fix issue #78. Commit when done." &
```

## OpenCode Deep Dive

### Key Flags
| Flag | Effect |
|------|--------|
| `run 'prompt'` | One-shot execution |
| `--continue` / `-c` | Continue last session |
| `--model provider/model` | Force specific model |
| `--thinking` | Show model thinking |
| `--file path` | Attach context files |

### Session Management
```bash
opencode session list    # List past sessions
opencode stats           # Token usage and costs
opencode -c              # Continue last session
```

### Pitfalls
- `/exit` is NOT a valid command — use Ctrl+C (`\x03`) to exit TUI
- Interactive sessions require `pty=true`
- Avoid sharing one working directory across parallel sessions

## General Rules

1. **Prefer print mode for single tasks** — cleaner, no dialog handling
2. **Use tmux for multi-turn interactive work** — only reliable way to orchestrate TUI
3. **Always set `workdir`** — keep agent focused on the right project
4. **Set `--max-turns` in print mode** — prevents infinite loops
5. **Monitor with `tmux capture-pane`** — check progress without interfering
6. **Clean up tmux sessions** — kill when done to avoid resource leaks
7. **Use `--allowedTools`** — restrict to what the task actually needs
