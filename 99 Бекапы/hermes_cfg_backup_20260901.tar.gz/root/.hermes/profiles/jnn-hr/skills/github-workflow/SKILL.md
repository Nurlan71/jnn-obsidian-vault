---
name: github
description: "Complete GitHub workflow: auth, repos, PRs, issues, code review, CI/CD, and codebase inspection."
version: 2.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [GitHub, Git, Pull-Requests, Issues, Code-Review, CI/CD, Repositories, Authentication]
---

# GitHub — Complete Workflow

This is the umbrella skill for all GitHub operations. It covers authentication, repository management, pull requests, issues, code review, and codebase inspection.

## Quick Navigation

| Topic | Section |
|-------|---------|
| Authentication & Setup | [§1 Authentication](#1-authentication-setup) |
| Repository Management | [§2 Repository Management](#2-repository-management) |
| Pull Request Lifecycle | [§3 Pull-request-lifecycle) |
| Code Review | [§4 Code Review](#4-code-review) |
| Issues Management | [§5 Issues Management](#5-issues-management) |
| Codebase Inspection | [§6 Codebase Inspection](#6-codebase-inspection) |

All sections show `gh` CLI first, then `git` + `curl` fallback for machines without `gh`.

---

## 1. Authentication & Setup

### Detection Flow

```bash
git --version
gh --version 2>/dev/null || echo "gh not installed"
gh auth status 2>/dev/null || echo "gh not authenticated"
```

### Method 1: Git-Only (No gh, No sudo)

**HTTPS with Personal Access Token:**
1. Create token at https://github.com/settings/tokens — scopes: `repo`, `workflow`, `read:org`
2. `git config --global credential.helper store`
3. Test: `git ls-remote https://github.com/<user>/<repo>.git`

**SSH Key Authentication:**
1. `ssh-keygen -t ed25519 -C "email" -f ~/.ssh/id_ed25519 -N ""`
2. Add public key at https://github.com/settings/keys
3. `ssh -T git@github.com`
4. `git config --global url."git@github.com:".insteadOf "https://github.com/"`

### Method 2: gh CLI Authentication

```bash
# Interactive (desktop)
gh auth login

# Headless / SSH servers
echo "<TOKEN>" | gh auth login --with-token
gh auth setup-git
```

### Auth Detection Helper

```bash
if command -v gh &>/dev/null && gh auth status &>/dev/null; then
  AUTH="gh"
elif [ -n "$GITHUB_TOKEN" ] || [ -f ~/.git-credentials ]; then
  AUTH="curl"
else
  AUTH="none"
fi
```

### Extracting Owner/Repo

```bash
REMOTE_URL=$(git remote get-url origin)
OWNER_REPO=$(echo "$REMOTE_URL" | sed -E 's|.*github\.com[:/]||; s|\.git$||')
OWNER=$(echo "$OWNER_REPO" | cut -d/ -f1)
REPO=$(echo "$OWNER_REPO" | cut -d/ -f2)
```

---

## 2. Repository Management

### Cloning

```bash
git clone https://github.com/owner/repo.git
git clone --depth 1 https://github.com/owner/repo.git  # shallow
gh repo clone owner/repo
```

### Creating Repositories

```bash
# With gh
gh repo create my-project --public --clone
gh repo create my-project --private --description "A tool" --license MIT --clone

# With curl
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/user/repos \
  -d '{"name":"my-project","private":false,"auto_init":true}'
```

### Forking

```bash
gh repo fork owner/repo --clone

# Or: curl -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/owner/repo/forks
```

### Repository Settings

```bash
gh repo edit --description "Updated" --visibility public
gh repo edit --default-branch main
gh repo edit --enable-auto-merge
```

### Branch Protection

```bash
curl -s -X PUT -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/branches/main/protection \
  -d '{
    "required_status_checks": {"strict":true,"contexts":["ci/test"]},
    "enforce_admins": false,
    "required_pull_request_reviews": {"required_approving_review_count":1},
    "restrictions": null
  }'
```

### Releases

```bash
gh release create v1.0.0 --title "v1.0.0" --generate-notes
gh release create v1.0.0 ./dist/binary --title "v1.0.0"
gh release list
```

### GitHub Actions

```bash
gh workflow list
gh run list --limit 10
gh run view <RUN_ID> --log-failed
gh run rerun <RUN_ID>
gh workflow run ci.yml --ref main
```

---

## 3. Pull Request Lifecycle

### Branch Creation

```bash
git fetch origin
git checkout main && git pull origin main
git checkout -b feat/add-feature
```

Branch naming: `feat/`, `fix/`, `refactor/`, `docs/`, `ci/`

### Making Commits

```bash
git add src/feature.py tests/test_feature.py
git commit -m "feat: add new feature

- Add feature X
- Add tests

Closes #42"
```

### Pushing and Creating a PR

```bash
git push -u origin HEAD

# With gh
gh pr create --title "feat: add feature" --body "Summary\n\nCloses #42"

# With curl
BRANCH=$(git branch --show-current)
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/pulls \
  -d '{"title":"feat: add feature","body":"Closes #42","head":"'"$BRANCH"'","base":"main"}'
```

### Monitoring CI

```bash
gh pr checks
gh pr checks --watch

# With curl
SHA=$(git rev-parse HEAD)
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/commits/$SHA/status \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['state'])"
```

### Merging

```bash
gh pr merge --squash --delete-branch
gh pr merge --auto --squash --delete-branch

# With curl
curl -s -X PUT -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/pulls/$PR_NUMBER/merge \
  -d '{"merge_method":"squash","commit_title":"feat: add feature (#N)"}'
```

---

## 4. Code Review

### Reviewing Local Changes (Pre-Push)

```bash
git diff main...HEAD --stat      # scope
git diff main...HEAD             # full diff
git diff main...HEAD --name-only # file names
```

**Review checklist:** Correctness, Security, Code Quality, Testing, Performance, Documentation.

### Reviewing a Pull Request

```bash
# With gh
gh pr view 123
gh pr diff 123
gh pr checkout 123

# Check out locally
git fetch origin pull/123/head:pr-123
git checkout pr-123
```

### Leaving Comments

```bash
# General comment
gh pr comment 123 --body "Looks good!"

# Inline comment
gh pr review 123 --request-changes --body "See inline comments."

# Formal review
gh pr review 123 --approve --body "LGTM!"
gh pr review 123 --request-changes --body "Issues found."
```

### Review Output Format

```
## Code Review Summary

### 🔴 Critical
- **src/auth.py:45** — SQL injection vulnerability

### ⚠️ Warnings
- **src/models.py:23** — Plaintext password storage

### 💡 Suggestions
- **src/utils.py:8** — Duplicated logic

### ✅ Looks Good
- Clean API design
```

---

## 5. Issues Management

### Viewing Issues

```bash
gh issue list
gh issue list --state open --label "bug"
gh issue list --assignee @me
gh issue view 42
```

### Creating Issues

```bash
gh issue create \
  --title "Login redirect ignores ?next= parameter" \
  --body "## Description\nAfter login, users always land on /dashboard." \
  --label "bug,backend"
```

### Managing Issues

```bash
# Labels
gh issue edit 42 --add-label "priority:high,bug"
gh issue edit 42 --remove-label "needs-triage"

# Assignment
gh issue edit 42 --add-assignee username

# Comment
gh issue comment 42 --body "Investigated — root cause found."

# Close / Reopen
gh issue close 42
gh issue reopen 42
```

### Issue Triage Workflow

1. List untriaged: `gh issue list --label "needs-triage" --state open`
2. Read and categorize each issue
3. Apply labels and priority
4. Assign if owner is clear
5. Comment with triage notes

---

## 6. Codebase Inspection

Analyze repositories for lines of code, language breakdown, file counts, and code-vs-comment ratios using `pygount`.

### Installation

```bash
pip install --break-system-packages pygount 2>/dev/null || pip install pygount
```

### Basic Summary

```bash
cd /path/to/repo
pygount --format=summary \
  --folders-to-skip=".git,node_modules,venv,.venv,__pycache__,.cache,dist,build" \
  .
```

### Common Exclusions

```bash
# Python projects
--folders-to-skip=".git,venv,.venv,__pycache__,.cache,dist,build,.tox,.eggs,.mypy_cache"

# JavaScript/TypeScript
--folders-to-skip=".git,node_modules,dist,build,.next,.cache,.turbo,coverage"
```

### Filter by Language

```bash
pygount --suffix=py --format=summary .
pygount --suffix=py,yaml,yml --format=summary .
```

### Output Columns

- **Language** — detected programming language
- **Files** — number of files
- **Code** — lines of actual code
- **Comment** — comment/documentation lines
- **%** — percentage of total

### Pitfalls

1. Always exclude `.git`, `node_modules`, `venv`
2. Markdown shows 0 code lines (expected)
3. For large monorepos, use `--suffix` to target specific languages

---

## Quick Reference Table

| Action | gh | git + curl |
|--------|-----|-----------|
| Clone | `gh repo clone o/r` | `git clone https://github.com/o/r.git` |
| Create repo | `gh repo create name --public` | `curl POST /user/repos` |
| Fork | `gh repo fork o/r --clone` | `curl POST /repos/o/r/forks` |
| Create PR | `gh pr create` | `curl POST /repos/o/r/pulls` |
| Merge | `gh pr merge --squash` | `curl PUT /repos/o/r/pulls/N/merge` |
| List issues | `gh issue list` | `curl GET /repos/o/r/issues` |
| Create issue | `gh issue create` | `curl POST /repos/o/r/issues` |
| Code review | `gh pr review` | `curl POST /repos/o/r/pulls/N/reviews` |
| Create release | `gh release create v1.0` | `curl POST /repos/o/r/releases` |
| List workflows | `gh workflow list` | `curl GET /repos/o/r/actions/workflows` |
