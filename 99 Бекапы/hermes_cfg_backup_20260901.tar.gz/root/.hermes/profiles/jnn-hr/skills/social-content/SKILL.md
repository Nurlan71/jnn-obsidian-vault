---
name: social-content
description: "Social media & content: X/Twitter posting/search, GIF search, YouTube transcript extraction and summarization."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [social-media, twitter, x, gif, youtube, content, search]
---

# Social Content — Social Media & Content Extraction

Umbrella skill for X/Twitter operations, GIF search, and YouTube content extraction.

## Quick Navigation

| Topic | Section |
|-------|---------|
| X/Twitter (xurl) | [§1 X/Twitter](#1-x-twitter) |
| GIF Search | [§2 GIF Search](#2-gif-search) |
| YouTube Content | [§3 YouTube Content](#3-youtube-content) |

---

## 1. X/Twitter

Official X API CLI. All commands return JSON.

### Installation
```bash
curl -fsSL https://raw.githubusercontent.com/xdevplatform/xurl/main/install.sh | bash
```

### Auth (user runs outside agent)
```bash
xurl auth apps add my-app --client-id ID --client-secret SECRET
xurl auth oauth2 --app my-app
xurl auth default my-app
```

### Key Commands

| Action | Command |
|--------|---------|
| Post | `xurl post "Hello world!"` |
| Reply | `xurl reply POST_ID "Nice!"` |
| Search | `xurl search "query" -n 10` |
| Timeline | `xurl timeline -n 20` |
| Like | `xurl like POST_ID` |
| Repost | `xurl repost POST_ID` |
| DM | `xurl dm @handle "message"` |
| Upload media | `xurl media upload photo.jpg` |

### Secret Safety
- **Never** read, print, or send `~/.xurl` to LLM context
- **Never** use `--verbose` in agent sessions (leaks auth headers)
- User must fill credentials manually outside agent session

---

## 2. GIF Search

Search and download GIFs via Tenor API.

### Setup
Set `TENOR_API_KEY` (free at https://developers.google.com/tenor/guides/quickstart)

### Search
```bash
curl -s "https://tenor.googleapis.com/v2/search?q=thumbs+up&limit=5&key=${TENOR_API_KEY}" \
  | jq -r '.results[].media_formats.gif.url'
```

### Download
```bash
URL=$(curl -s "https://tenor.googleapis.com/v2/search?q=celebration&limit=1&key=${TENOR_API_KEY}" \
  | jq -r '.results[0].media_formats.gif.url')
curl -sL "$URL" -o celebration.gif
```

---

## 3. YouTube Content

Extract transcripts and convert to summaries, threads, blogs.

### Installation
```bash
pip install youtube-transcript-api
```

### Fetch Transcript
```bash
python3 scripts/fetch_transcript.py "https://youtube.com/watch?v=VIDEO_ID"
python3 scripts/fetch_transcript.py "URL" --text-only --timestamps
python3 scripts/fetch_transcript.py "URL" --language tr,en
```

### Output Formats
- **Chapters** — Timestamped topic breakdown
- **Summary** — 5-10 sentence overview
- **Thread** — Twitter/X thread format (≤280 chars per post)
- **Blog post** — Full article with sections
- **Quotes** — Notable quotes with timestamps

### Workflow
1. Fetch transcript with `--text-only --timestamps`
2. Validate non-empty output
3. Chunk if >50K chars (40K with 2K overlap)
4. Transform to requested format
5. Verify coherence before presenting
