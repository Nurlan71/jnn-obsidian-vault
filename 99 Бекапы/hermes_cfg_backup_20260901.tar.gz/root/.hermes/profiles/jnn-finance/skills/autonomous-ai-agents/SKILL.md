---
name: autonomous-ai-agents
description: "Autonomous AI agent roster: coding agents (Claude Code, Codex, OpenCode), business agents (finance, HR, sales, marketing, production, operations), and agent orchestration patterns."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [agents, autonomous, coding, business, finance, hr, sales, marketing, production, orchestration]
    related_skills: [claude-code, codex, opencode, finance, hr, marketer, navigator, production, rop, sales, habit-tracker, hermes-agent]
---

# Autonomous AI Agents

This is the umbrella skill for configuring and orchestrating autonomous AI agents — both coding CLIs and business role agents.

---

## Coding Agents

### Claude Code

Anthropic's autonomous coding agent CLI. Hermes orchestrates via print mode (`-p`) or interactive PTY.

```bash
npm install -g @anthropic-ai/claude-code
claude -p "Add error handling to API calls" --allowedTools "Read,Edit" --max-turns 10
```

**Modes:** Print mode (preferred) or interactive PTY via tmux.
**Auth:** `claude auth login` (browser OAuth) or `ANTHROPIC_API_KEY`.

### Codex

OpenAI's autonomous coding agent CLI.

```bash
npm install -g @openai/codex
codex "Refactor the auth module" --model o4-mini
```

**Auth:** `OPENAI_API_KEY` or Codex OAuth.

### OpenCode

Provider-agnostic open-source AI coding agent.

```bash
npm i -g opencode-ai@latest
opencode run "Implement feature X"
```

**Auth:** `opencode auth login` or provider env vars (OPENROUTER_API_KEY, etc.).

---

## Business Role Agents

These agents are specialized personas for business functions. Each has its own trigger vocabulary and domain expertise.

### Navigator (COO / Orchestrator)

The senior agent that orchestrates the team. Spawns sub-agents, delegates tasks, monitors progress, aggregates results.

**Triggers:** Multi-agent coordination, task delegation, oversight.

### Finance (Финдир)

Budgeting, expense tracking, invoicing, financial reporting, cash-flow management.

**Triggers:** финансы, бюджет, расходы, доходы, счёт, инвойс, налоги, cashflow, P&L, balance sheet.

### HR (HR-директор)

Recruitment, onboarding, employee records, payroll, team coordination.

**Triggers:** HR, hiring, onboarding, payroll, employee, team.

### Sales (Продажник)

Lead generation, outreach, deal tracking, revenue forecasting.

**Triggers:** sales, leads, outreach, deals, revenue, pipeline.

### Marketing (Маркетолог)

Market research, campaign creation, content generation, advertising, brand management.

**Triggers:** marketing, campaigns, content, ads, brand, social media.

### Production (Производство)

Manufacturing workflow, bill of materials, inventory, quality control, scheduling.

**Triggers:** production, manufacturing, BOM, inventory, scheduling, QC.

### Operations (ROP)

Oversees operational processes, coordinates production, ensures SLA compliance, optimizes workflow.

**Triggers:** operations, SLA, workflow optimization, process improvement.

### Habit Tracker

Personal habit tracking with daily check-ins, streak counting, markdown charts.

**Triggers:** habits, daily tracking, streaks, personal development.

---

## Hermes Agent Configuration

For configuring, extending, or contributing to Hermes Agent itself, see the `hermes-agent` skill (separate).

---

## Agent Orchestration Patterns

### Single Agent Delegation

Spawn one agent for a focused task:
```
claude -p "Fix the login bug" --allowedTools "Read,Edit,Bash"
```

### Parallel Multi-Agent

Spawn multiple agents for independent subtasks:
```
claude -p "Implement feature A" &
claude -p "Implement feature B" &
wait
```

### Navigator Pattern

Navigator delegates to specialists:
1. Navigator receives task
2. Decomposes into subtasks
3. Spawns appropriate specialist agents
4. Monitors progress
5. Aggregates results
