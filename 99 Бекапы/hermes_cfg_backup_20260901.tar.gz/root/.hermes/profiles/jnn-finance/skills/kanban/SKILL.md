---
name: kanban
description: "Kanban multi-agent workflow: orchestrator decomposition playbook + worker pitfalls and examples."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [kanban, multi-agent, orchestration, workflow, collaboration]
    related_skills: [kanban-orchestrator, kanban-worker]
---

# Kanban Multi-Agent Workflow

This is the umbrella skill for the Kanban multi-agent system. It covers both the orchestrator (decomposition and routing) and worker (execution and pitfalls) roles.

---

## Orchestrator Role

The orchestrator's job is to decompose tasks and route them to workers — **not to do the work yourself**.

### Decomposition Playbook

1. **Receive task** — Understand the full scope
2. **Decompose** — Break into independent subtasks
3. **Route** — Assign to appropriate worker profiles
4. **Monitor** — Track progress via heartbeats
5. **Aggregate** — Collect and synthesize results

### Anti-Temptation Rules

- Don't execute subtasks yourself
- Don't micromanage workers
- Don't skip decomposition for "simple" tasks
- Trust the worker lifecycle

### Profiles Are User-Configured

Hermes setups vary. Some run a single profile; some run a fleet (docker-worker, cron-worker, specialists). There is no default roster — the orchestrator discovers what profiles exist at runtime.

---

## Worker Role

Workers execute subtasks dispatched by the orchestrator.

### Lifecycle (6 Steps)

1. **Orient** — Read the task, understand requirements, check workspace
2. **Work** — Execute the task
3. **Heartbeat** — Report progress periodically
4. **Block** — If stuck, report blocker and wait
5. **Complete** — Mark done, report results
6. **Handoff** — Clean up workspace, pass results back

### Workspace Handling

Your workspace kind determines behavior inside `$HERMES_KANBAN_WORKSPACE`:
- **Shared** — Coordinate with other workers
- **Isolated** — Work independently
- **Ephemeral** — Clean up after completion

### Common Pitfalls

- Not reporting heartbeats (orchestrator thinks you're stuck)
- Modifying shared state without coordination
- Not cleaning up ephemeral workspaces
- Ignoring blockers instead of reporting them
