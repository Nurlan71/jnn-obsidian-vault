---
name: mlops
description: "ML operations: model evaluation, experiment tracking, inference, serving, HuggingFace Hub, audio generation, image segmentation."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [mlops, machine-learning, evaluation, inference, serving, huggingface, audio, vision]
    related_skills: [evaluating-llms-harness, weights-and-biases, serving-llms-vllm, llama-cpp, obliteratus, huggingface-hub, segment-anything-model, audiocraft-audio-generation]
---

# MLOps — Machine Learning Operations

This is the umbrella skill for ML operations. It covers model evaluation, experiment tracking, inference, serving, model management, and specialized ML tasks.

---

## 1. LLM Evaluation (lm-evaluation-harness)

Evaluate LLMs across 60+ academic benchmarks (MMLU, HumanEval, GSM8K, TruthfulQA, HellaSwag).

```bash
# Install
pip install lm-eval

# Run benchmarks
lm-eval --model hf --model_args pretrained=meta-llama/Llama-2-7b-hf \
  --tasks mmlu,gsm8k --device cuda --batch_size auto

# With vLLM backend
lm-eval --model vllm --model_args pretrained=model-name \
  --tasks hellaswag --batch_size 32
```

Supports: HuggingFace, vLLM, OpenAI API backends.

---

## 2. Experiment Tracking (Weights & Biases)

Track ML experiments with automatic metric logging, hyperparameter sweeps, and model registry.

```python
import wandb
wandb.init(project="my-project", config={"lr": 0.001, "epochs": 10})
wandb.log({"loss": 0.5, "accuracy": 0.95})
wandb.finish()
```

```bash
# CLI
wandb login
wandb sweep sweep.yaml
wandb agent <sweep_id>
```

---

## 3. Local Inference (llama.cpp)

Run GGUF models locally on CPU, Apple Silicon, CUDA, or ROCm.

```bash
# Install
pip install llama-cpp-python

# Python
from llama_cpp import Llama
llm = Llama(model_path="model-q4_k_m.gguf", n_ctx=4096)
output = llm("Hello, world!", max_tokens=128)
```

Quantization guide: Q4_K_M (best quality/size tradeoff), Q5_K_M (higher quality), Q8_0 (near-full).

---

## 4. High-Throughput Serving (vLLM)

Production LLM serving with PagedAttention, continuous batching, and OpenAI-compatible API.

```bash
# Install
pip install vllm

# Serve
python -m vllm.entrypoints.openai.api_server \
  --model meta-llama/Llama-2-7b-hf --dtype auto

# Python
from vllm import LLM, SamplingParams
llm = LLM(model="model-name", tensor_parallel_size=2)
outputs = llm.generate(["Hello"], SamplingParams(temperature=0.7))
```

Supports: GPTQ/AWQ/FP8 quantization, tensor parallelism, prefix caching.

---

## 5. Model Surgery (OBLITERATUS)

Abliterate LLM refusals using diff-in-means weight projection.

```bash
# Install
pip install obliteratus

# Run
obliteratus abliterate --model meta-llama/Llama-2-7b-hf \
  --output llama-2-7b-abliterated --method diff-in-means
```

9 CLI methods, 28 analysis modules, 116 model presets across 5 compute tiers.

---

## 6. HuggingFace Hub (hf CLI)

Search, download, upload models and datasets.

```bash
# Install
pip install huggingface-hub

# Search
hf search "llama" --limit 10

# Download
hf download meta-llama/Llama-2-7b-hf

# Upload
hf upload ./my-model --repo-id username/my-model

# Repo management
hf repo create my-model --type model
```

---

## 7. Image Segmentation (SAM)

Zero-shot image segmentation via points, boxes, or masks.

```python
from segment_anything import sam_model_registry, SamPredictor
sam = sam_model_registry["vit_h"](checkpoint="sam_vit_h.pth")
predictor = SamPredictor(sam)
predictor.set_image(image)
masks, scores, logits = predictor.predict(point_coords=points, point_labels=labels)
```

---

## 8. Audio Generation (AudioCraft)

Text-to-music and text-to-sound generation.

```python
from audiocraft.models import MusicGen
model = MusicGen.get_pretrained('facebook/musicgen-medium')
model.set_generation_params(duration=30)
wav = model.generate(['upbeat jazz with piano'])
```

Supports: MusicGen (text-to-music), AudioGen (text-to-sound), EnCodec (compression).
