---
name: macos
description: "macOS integrations: Notes, Reminders, iMessage, Find My, desktop automation."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [macOS, Apple, iMessage, Notes, Reminders, FindMy, desktop, automation]
    related_skills: [apple-notes, apple-reminders, findmy, imessage, macos-computer-use]
---

# macOS Integrations

This is the umbrella skill for macOS-specific integrations. All skills in this collection require macOS and will not load on Linux/Windows.

---

## 1. Apple Notes (`memo`)

Manage Apple Notes via the `memo` CLI.

**Install:** `brew tap antoniorodr/memo && brew install antoniorodr/memo/memo`
**Grant:** Automation access to Notes.app (System Settings → Privacy → Automation)

```bash
memo list                    # List all notes
memo search "query"          # Search notes
memo create "Title" "Body"   # Create a new note
memo edit "Title" "New body" # EditExisting note
memo delete "Title"          # Delete a note
memo folders                 # List folders
```

---

## 2. Apple Reminders (`remindctl`)

Manage Apple Reminders via `remindctl`.

**Install:** `brew install steipete/tap/remindctl`
**Grant:** Reminders permission when prompted

```bash
remindctl status             # Check authorization
remindctl authorize          # Request access
remindctl list               # List all reminders
remindctl list --list "Name" # List reminders in a specific list
remindctl add "Title" --due "2024-12-25" --list "Personal"
remindctl complete <id>      # Mark as done
remindctl delete <id>        # Delete
```

---

## 3. Find My

Track Apple devices and AirTags via FindMy.app using AppleScript + screen capture.

**Requires:** macOS with Find My app, iCloud signed in, Screen Recording permission.

### With `peekaboo` (recommended)

**Install:** `brew install steipete/tap/peekaboo`

```bash
# Open Find My and capture the window
peekaboo capture --app "Find My"
```

### With AppleScript

```bash
osascript -e '
tell application "Find My"
    activate
end tell
delay 2
-- Use browser_vision or screenshot to read device locations
'
```

---

## 4. iMessage (`imsg`)

Send and receive iMessages/SMS via the `imsg` CLI.

**Install:** `brew install steipete/tap/imsg`
**Grant:** Full Disk Access + Automation for Messages.app

```bash
imsg list                    # List recent conversations
imsg history --chat "Name"   # Show chat history
imsg send --to "+1234567890" --text "Hello!"
imsg send --to "email@example.com" --text "Hello!"
imsg group --name "Family" --members "+123" --text "Dinner at 7"
imsg watch                   # Watch for new messages
```

---

## 5. macOS Computer Use

Drive the macOS desktop in the background — screenshots, mouse, keyboard, scroll, drag — without stealing the user's cursor or keyboard focus.

### The Canonical Workflow

1. **Capture first** — always start with a screenshot to see the current state
2. **Plan** — identify the target elements and their positions
3. **Act** — click, type, scroll, or drag as needed
4. **Verify** — capture again to confirm the action had the expected effect

### Background Operation

Actions do NOT move the user's cursor, steal keyboard focus, or switch Spaces. The user can keep typing in their editor while you work in another Space.

### Common Patterns

```bash
# Take screenshots (built-in)
screencapture -x /tmp/screen.png  # Full screen
screencapture -x -R0,0,800,600 /tmp/region.png  # Region

# Use browser_vision to read screen content
# Then use computer_use tool to interact
```

### Permissions Required

- **Screen Recording** — for screenshots (System Settings → Privacy → Screen Recording)
- **Accessibility** — for mouse/keyboard control
- **Automation** — for controlling specific apps
