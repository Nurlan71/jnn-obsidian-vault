---
name: github
description: "Complete GitHub workflow: auth, issues, PRs, code review, repo management, releases, Actions, codebase inspection."
version: 2.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [GitHub, Git, Pull-Requests, Issues, Code-Review, CI/CD, Releases, Automation]
    related_skills: [github-auth, github-code-review, github-issues, github-pr-workflow, github-repo-management]
---

# GitHub — Complete Workflow Guide

This is the umbrella skill for all GitHub operations. It covers authentication, issues, pull requests, code review, repository management, releases, and GitHub Actions.

**Platform note:** Every section shows the `gh` CLI way first, then the `git` + `curl` fallback for machines without `gh`.

## Quick Auth Detection

Run this at the start of any GitHub workflow:

```bash
if command -v gh &>/dev/null && gh auth status &>/dev/null; then
  AUTH="gh"
else
  AUTH="git"
  if [ -z "$GITHUB_TOKEN" ]; then
    if [ -f ~/.hermes/.env ] && grep -q "^GITHUB_TOKEN=" ~/.hermes/.env; then
      GITHUB_TOKEN=$(grep "^GITHUB_TOKEN=" ~/.hermes/.env | head -1 | cut -d= -f2 | tr -d '\n\r')
    elif grep -q "github.com" ~/.git-credentials 2>/dev/null; then
      GITHUB_TOKEN=$(grep "github.com" ~/.git-credentials 2>/dev/null | head -1 | sed 's|https://[^:]*:\([^@]*\)@.*|\1|')
    fi
  fi
fi

REMOTE_URL=$(git remote get-url origin)
OWNER_REPO=$(echo "$REMOTE_URL" | sed -E 's|.*github\.com[:/]||; s|\.git$||')
OWNER=$(echo "$OWNER_REPO" | cut -d/ -f1)
REPO=$(echo "$OWNER_REPO" | cut -d/ -f2)
```

---

## 1. Authentication

See `scripts/gh-env.sh` for a reusable auth-detection helper.

### Method 1: Git-Only (No gh, No sudo)

**HTTPS with Personal Access Token:**
1. Create token at https://github.com/settings/tokens — scopes: `repo`, `workflow`, `read:org`
2. `git config --global credential.helper store`
3. Do a test operation; enter username + token as password

**SSH Key:**
1. `ssh-keygen -t ed25519 -C "email" -f ~/.ssh/id_ed25519 -N ""`
2. Add public key at https://github.com/settings/keys
3. `git config --global url."git@github.com:".insteadOf "https://github.com/"`

### Method 2: gh CLI

```bash
gh auth login          # interactive
echo "$TOKEN" | gh auth login -- with-token  # headless
gh auth setup-git
```

### Troubleshooting

| Problem | Solution |
|---------|----------|
| `git push` asks for password | Use PAT as password, or switch to SSH |
| `Permission denied` | Token may lack `repo` scope |
| `Authentication failed` | Run `git credential reject` then re-auth |
| SSH port 22 refused | Use `Port 443` + `Hostname ssh.github.com` in `~/.ssh/config` |

---

## 2. Issues

### Viewing

```bash
# gh
gh issue list --state open --label "bug"
gh issue view 42

# curl
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/repos/$OWNER/$REPO/issues?state=open&per_page=20"
```

### Creating

```bash
# gh
gh issue create --title "..." --body "..." --label "bug" --assignee "user"

# curl
curl -s -X POST -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/repos/$OWNER/$REPO/issues \
  -d '{"title":"...","body":"...","labels":["bug"]}'
```

Templates: `templates/bug-report.md`, `templates/feature-request.md`.

### Managing

```bash
# Labels
gh issue edit 42 --add-label "priority:high"
# curl: POST /repos/{o}/{r}/issues/{n}/labels  with  {"labels":["priority:high"]}

# Assign
gh issue edit 42 --add-assignee username
# curl: POST /repos/{o}/{r}/issues/{n}/assignees  with  {"assignees":["username"]}

# Comment
gh issue comment 42 --body "..."
# curl: POST /repos/{o}/{r}/issues/{n}/comments  with  {"body":"..."}

# Close / Reopen
gh issue close 42
# curl: PATCH /repos/{o}/{r}/issues/{n}  with  {"state":"closed"}
```

### Triage Workflow

1. List untriaged: `gh issue list --label "needs-triage"`
2. Read and categorize each issue
3. Apply labels, priority, assignee
4. Comment with triage notes

---

## 3. Pull Request Workflow

### Branch → Commit → Push → PR

```bash
git checkout main && git pull origin main
git checkout -b feat/my-feature
# (make changes)
git add . && git commit -m "feat: description"
git push -u origin HEAD

# Create PR
gh pr create --title "feat: ..." --body "..." --reviewer user1
# curl: POST /repos/{o}/{r}/pulls  with  {"title":"...","head":"branch","base":"main"}
```

Branch naming: `feat/`, `fix/`, `refactor/`, `docs/`, `ci/`
Commit format: see `references/conventional-commits.md`
PR body templates: `templates/pr-body-feature.md`, `templates/pr-body-bugfix.md`

### Monitoring CI

```bash
gh pr checks --watch

# curl: GET /repos/{o}/{r}/commits/{sha}/status
# curl: GET /repos/{o}/{r}/commits/{sha}/check-runs
```

### Auto-Fix CI Loop

1. Check CI → identify failures
2. Read logs: `gh run view <ID> --log-failed`
3. Fix code with `patch`/`write_file`
4. `git add . && git commit -m "fix: ..." && git push`
5. Re-check CI; repeat up to 3 times

See `references/ci-troubleshooting.md` for common failure patterns.

### Merging

```bash
gh pr merge --squash --delete-branch
# curl: PUT /repos/{o}/{r}/pulls/{n}/merge  with  {"merge_method":"squash"}
```

---

## 4. Code Review

### Local Changes (Pre-Push)

```bash
git diff main...HEAD --stat      # scope
git diff main...HEAD             # full diff
git diff main...HEAD | grep -n "print\|console.log\|TODO\|FIXME"
```

Review checklist: Correctness, Security, Code Quality, Testing, Performance, Documentation.

Output format: Critical / Warnings / Suggestions / Looks Good.
See `references/review-output-template.md`.

### Reviewing a PR

```bash
# Fetch and check out
git fetch origin pull/N/head:pr-N && git checkout pr-N
# or: gh pr checkout N

# Read diff
git diff main...HEAD
```

### Inline Comments

```bash
# gh
gh api repos/$OWNER/$REPO/pulls/N/comments --method POST \
  -f body="..." -f path="file.py" -f commit_id="$SHA" -f line=45

# curl: POST /repos/{o}/{r}/pulls/{n}/comments
```

### Formal Review

```bash
gh pr review N --approve --body "LGTM"
gh pr review N --request-changes --body "See inline comments"

# curl: POST /repos/{o}/{r}/pulls/{n}/reviews
# Body: {"commit_id":"...","event":"APPROVE","body":"...","comments":[...]}
```

Event values: `APPROVE`, `REQUEST_CHANGES`, `COMMENT`

---

## 5. Repository Management

### Clone / Create / Fork

```bash
# Clone
git clone https://github.com/owner/repo.git
gh repo clone owner/repo

# Create
gh repo create name --public --clone
# curl: POST /user/repos

# Fork
gh repo fork owner/repo --clone
# curl: POST /repos/{o}/{r}/forks, then git clone + git remote add upstream
```

### Settings & Branch Protection

```bash
gh repo edit --description "..." --visibility public
# curl: PATCH /repos/{o}/{r}

# Branch protection: PUT /repos/{o}/{r}/branches/main/protection
```

### Secrets

```bash
gh secret set API_KEY --body "value"
gh secret list
# curl: requires encryption with repo public key (use gh when possible)
```

### Releases

```bash
gh release create v1.0.0 --title "v1.0.0" --generate-notes
# curl: POST /repos/{o}/{r}/releases

# Upload asset
curl -X POST -H "Authorization: token $GITHUB_TOKEN" \
  -H "Content-Type: application/octet-stream" \
  "https://uploads.github.com/repos/$OWNER/$REPO/releases/$ID/assets?name=binary" \
  --data-binary @./binary
```

### GitHub Actions

```bash
gh workflow list
gh run list --limit 10
gh run view <ID> --log-failed
gh run rerun <ID>
# curl: GET/POST /repos/{o}/{r}/actions/...
```

See `references/github-api-cheatsheet.md` for the full REST API quick reference.

---

## Quick Reference Table

| Action | gh | curl endpoint |
|--------|-----|--------------|
| Auth status | `gh auth status` | `GET /user` |
| List issues | `gh issue list` | `GET /repos/{o}/{r}/issues` |
| Create PR | `gh pr create` | `POST /repos/{o}/{r}/pulls` |
| PR checks | `gh pr checks` | `GET /repos/{o}/{r}/commits/{sha}/status` |
| Merge | `gh pr merge` | `PUT /repos/{o}/{r}/pulls/{n}/merge` |
| Create release | `gh release create` | `POST /repos/{o}/{r}/releases` |
| Set secret | `gh secret set` | `PUT /repos/{o}/{r}/actions/secrets/{key}` |

---

## 6. Codebase Inspection (pygount)

Inspect codebases for LOC, language breakdown, and ratios.

```bash
# Install
pip install pygount

# Basic usage
pygount --format summary src/
pygount --format detail src/
pygount --out report.json --format json src/

# Filter by language
pygount --names-to-suffix=.py,.js,.ts src/
```

Output includes: language, files, blank lines, comment lines, code lines, and comment-to-code ratio.
