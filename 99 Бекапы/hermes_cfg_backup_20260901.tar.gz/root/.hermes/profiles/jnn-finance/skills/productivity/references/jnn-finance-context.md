# JNN Factory — Finance Context

Session-specific context for the JNN Factory finance agent. Loaded automatically
by the `productivity` umbrella when the agent works on JNN financial tasks.

## Company Profile

- **JNN Factory** — производство одежды, Бишкек (Кыргызстан)
- **Валюта:** кыргызские сомы (KGS). Формат сумм: с двумя знаками, разделитель тысяч — пробел (`258 039 сом`)
- **Часовой пояс:** Asia/Bishkek (UTC+6)
- **Пользователь (собственник):** Nurlan — краткие ответы, без лишних вопросов; сам решает куда и что вносить; не любит когда данные угадывают

## Google Sheets (JNN Drive)

| Документ | ID | Назначение | Агент |
|---|---|---|---|
| **JNN \| Финансы** | `1449eIK17FqKf-4d-eZe6bJhiWVRpNXLpCk7wKgS_tvs` | Реестр операций, ДДС, ОПиУ, Баланс, Себестоимость, Дебиторка/Кредиторка, Зарплаты, Налоговый календарь, Бюджет vs Факт | Финдир |
| **JNN \| Заказы швейного цеха** | `1NYGShG9Nm76FLt4wRnSXbgjwJ2lTxUOnKzd831Vjhss` | Заказы на пошив | Производство |
| **JNN \| Лиды и Продажи** | `1Ry0jICE-yW_UfAEipRE9vscKx4EbGDU55OKCXxL0m1o` | Воронка продаж | Продажник, РОП |
| **JNN \| HR Сотрудники** | `1MczfFtALr4jMcrpoOTdacBxQgh8Gd3lfnsLQtvIJP6A` | Штатное расписание | HR |
| **JNN Dashboard** | `1GpCBkOs6djJf8Jh0KeBNcxJh5d1P-LNOwYoXgGT0Ls` | Сводка KPI: оборот, маржа, ДДС, дебиторка. Автосинхронизация каждые 15 минут | Навигатор |

- **rclone config:** `/root/.hermes/profiles/jnn-finance/rclone.conf`
- **Правило:** ВСЕ операции через rclone + Sheets API. НИКОГДА `gws` / `google-workspace` skill.
- **Cyrillic имена листов** — URL-encode через `urllib.parse.quote()`.

## JNN Skill Library — Internal Layout

Hermes-скиллы для JNN разложены в `/opt/data/jnn-hermes-skills/`:

```
/opt/data/jnn-hermes-skills/
├── central/          # JNN-специфичные агенты (jnn-finance-skill.md, jnn_emit_event.py)
├── finance/          # клон skills/ для профиля финдира (xlsx, obsidian, weekly-review и т.д.)
├── habit/ hr/ marketer/ navigator/ production/ rop/ sales/
└── jnn-custom/       # JNN бизнес-агенты и кастомные скиллы
```

**Важно:** `/opt/data/jnn-hermes-skills/<profile>/` — это **зеркало бандлов Hermes**,
а НЕ активный набор. Чтобы активировать скилл, нужно скопировать его в
`~/.hermes/profiles/jnn-finance/skills/<category>/<skill>/SKILL.md` вручную
(или через `hermes skills install`).

`central/jnn-finance-skill.md` — **наш собственный скилл финдира** с готовыми
процедурами для Реестра операций, ДДС, ОПиУ, Баланса, Себестоимости, зарплат,
налогового календаря. Содержит формулы:
- Полная себестоимость = Материалы + Работа + Накладные
- Маржинальность = (Выручка - Переменные расходы) / Выручка × 100%
- Оборачиваемость ДЗ = Средняя ДЗ / Выручка × 365

## Стиль ответов для пользователя

- Без угадывания данных (имён, сумм, ставок) — уточнять явно
- Не предлагать "ничего не делать" как дефолт — пользователь хочет конкретные шаги
- Не загружать GitHub-curated списками скиллов прежде чем проверить что уже есть локально
- Финдир пишет в Telegram → bullets, лаконично, без таблиц (Telegram их плохо рендерит)
- Перед каждым важным действием писать в лог `/opt/shared/agent-logs/agent-log.sh "FINANCE" "<action>" "<details>"`