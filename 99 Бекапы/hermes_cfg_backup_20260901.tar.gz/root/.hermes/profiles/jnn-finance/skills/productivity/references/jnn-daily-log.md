# JNN Daily Log Format

JNN Factory vault (`/root/.hermes/Obsidian/JNN-Vault/`) uses a structured daily log format in `daily/YYYY-MM-DD.md`.

## Structure

```markdown
# Daily Log — 2026-07-28

## HH:MM - [agent-name]
- Пользователь: Nurlan
- Задача: <short task description>
- Статус: Выполнено / В работе / Отменено
- Результат:
  • bullet point 1
  • bullet point 2
```

## Conventions

- **Timestamp**: 24-hour format in Asia/Bishkek (UTC+6) timezone
- **Agent tag**: lowercase with hyphens — `[jnn-finance]`, `[jnn-marketer]`, `[navigator]`, `[jnn-sales]`
- **Пользователь**: typically "Nurlan"
- **Результат**: use bullet points (•) for multi-line results
- **Appending**: use `patch` to add a new section after the last existing section
- **File path**: `/root/.hermes/Obsidian/JNN-Vault/daily/YYYY-MM-DD.md`

## Example

```
## 19:55 - [jnn-finance]
- Пользователь: Nurlan
- Задача: Проверка остатка на счёте и расчёт маржи заказа №007
- Статус: Выполнено
- Результат:
  • Остаток на счёте (ДДС): **258 039 сом**
  • Заказ №007 — Юбка с шортами (256 шт), маржа 26.6%
  • Статус заказа: Готов
```
