---
name: productivity
description: "Productivity tools: Airtable, Google Workspace, Notion, PDF editing, OCR, PowerPoint, maps, Teams meetings."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [productivity, airtable, google, notion, pdf, ocr, powerpoint, maps, teams]
    related_skills: [airtable, google-workspace, notion, nano-pdf, ocr-and-documents, powerpoint, maps, teams-meeting-pipeline]
---

# Productivity Tools

This is the umbrella skill for productivity and office tools.

---

## 1. Airtable

Airtable REST API via curl. Records CRUD, filters, upserts.

```bash
# Requires AIRTABLE_API_KEY
curl "https://api.airtable.com/v0/{baseId}/{tableName}" \
  -H "Authorization: Bearer $AIRTABLE_API_KEY"

# Create record
curl -X POST "https://api.airtable.com/v0/{baseId}/{tableName}" \
  -H "Authorization: Bearer $AIRTABLE_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"fields": {"Name": "Example", "Status": "Active"}}'
```

---

## 2. Google Drive (rclone + Sheets API)

**CRITICAL: Do NOT use `gws` or `google-workspace` tools — they require separate OAuth and DO NOT work.** Use rclone + Sheets API with curl instead. Token lives in the profile's `rclone.conf`.

### 2.1 List files in a Drive folder

```bash
# List all files with names, sizes, dates
rclone --config /root/.hermes/profiles/jnn-finance/rclone.conf lsl "gdrive:/JNN - Производство/"

# List with file IDs (for Sheets API calls)
rclone --config /root/.hermes/profiles/jnn-finance/rclone.conf lsf "gdrive:/JNN - Производство/" --format "ip"

# List folders only
rclone --config /root/.hermes/profiles/jnn-finance/rclone.conf lsd "gdrive:/"
```

### 2.2 Read Google Sheets via API

```bash
# IMPORTANT: Run a simple rclone command first to refresh the token
# (stale tokens cause 401 errors from Sheets API)
rclone --config /root/.hermes/profiles/jnn-finance/rclone.conf lsd gdrive:/ >/dev/null 2>&1

# Get access token from rclone config
TOKEN=$(python3 -c "
import json
with open('/root/.hermes/profiles/jnn-finance/rclone.conf') as f:
    for line in f:
        if line.strip().startswith('token'):
            tok = json.loads(line.split(' = ', 1)[1])
            print(tok['access_token'])
            break
")

# Get sheet metadata (list of sheets/tabs)
curl -s "https://sheets.googleapis.com/v4/spreadsheets/SHEET_ID?fields=sheets.properties" \
  -H "Authorization: Bearer $TOKEN"

# Read data from a sheet (URL-encode Cyrillic sheet names!)
curl -s "https://sheets.googleapis.com/v4/spreadsheets/SHEET_ID/values/%27%D0%9B%D0%B8%D1%81%D1%821%27" \
  -H "Authorization: Bearer $TOKEN"
```

### 2.3 Key pitfalls

| Pitfall | Fix |
|---|---|
| **Cyrillic sheet names break API calls** — `Лист1`, `Шаблоны операций` etc. need URL encoding | Python `urllib.parse.quote(name)` before inserting into URL |
| **Size -1 in rclone lsl** — not an error; marks native Google Sheets (not uploaded xlsx files) | These ARE Sheets, read via API. Real xlsx files have positive byte sizes and need `rclone cat` |
| **`gws` tool doesn't work** — requires separate OAuth that isn't configured | Never use it. Always rclone + Sheets API |
| **API returns empty values array** — the Sheet has only headers or is truly empty | Check `values` length: 0 = empty, 1 = headers only, >1 = real data |

### 2.4 Detect duplicates across a folder

Pattern: enumerate files with `rclone lsf --format "ip"`, group by name similarity, compare Sheet contents via API.

- Same name + different ID → duplicate Sheet (e.g. two `JNN — Реестр техкарт.xlsx`)
- Same name + .xlsx.xlsx suffix → likely a duplicate upload artifact
- Same file in multiple subfolders (`..._updated.xlsx/`, `temp_upload.xlsx/`, `orders_updated.xlsx/`) → technical duplicates from re-uploads

### 2.5 Copy/download files

```bash
# Download a file
rclone --config /root/.hermes/profiles/jnn-finance/rclone.conf copy "gdrive:/JNN - Производство/file.xlsx" /tmp/

# Copy to another Drive folder
rclone --config /root/.hermes/profiles/jnn-finance/rclone.conf copy "gdrive:/source/" "gdrive:/dest/"
```

### 2.6 JNN Daily Log (Obsidian)

After completing finance tasks, log results to the JNN daily note.

See `references/jnn-daily-log.md` for the exact format.

```bash
# File path
/root/.hermes/Obsidian/JNN-Vault/daily/YYYY-MM-DD.md
```

### 2.7 JNN Factory context (production company, Bishkek, KGS)

Sheet IDs, currency conventions, user style, and JNN-specific pitfalls
(skills not auto-installed per profile, rclone-only workflow,
Cyrillic sheet names). Always read this file before recommending
external tools or skills — JNN has an internal skill library that
takes priority over GitHub-curated lists.

See `references/jnn-finance-context.md`.

### 2.8 Pitfall: don't propose GitHub installs before checking local state

When the user asks for skill recommendations, always audit first:

```bash
hermes skills list                                   # active in this profile
ls ~/.hermes/profiles/<this-profile>/skills/         # local overrides
ls /opt/data/jnn-hermes-skills/<this-profile>/       # JNN skill mirror
rclone lsf gdrive:/ --dirs-only                      # Drive layout
ls /root/.hermes/Obsidian/JNN-Vault/                 # vault layout
```

Only after this — propose new installs. The JNN-mirrored skill
(`/opt/data/jnn-hermes-skills/<profile>/...`) is often already
on disk; it only needs copying into `~/.hermes/profiles/<profile>/skills/`.
A round of "let me find skills on GitHub" without this check
delivers generic Tier1/Tier2/Tier3 lists and erodes user trust.

---

## 3. Notion

Notion API + ntn CLI: pages, databases, markdown.

```bash
# Requires NOTION_API_KEY
ntn page create --parent "PAGE_ID" --title "New Page"
ntn database query --database "DB_ID" --filter '{"property": "Status", "select": {"equals": "Done"}}'
ntn page export --page "PAGE_ID" --format markdown
```

---

## 4. PDF Editing (nano-pdf)

Edit PDF text/typos/titles via natural language prompts.

```bash
nano-pdf edit document.pdf "Fix the typo on page 3"
nano-pdf title document.pdf "New Title"
```

---

## 5. OCR & Document Extraction

Extract text from PDFs and scanned documents.

```bash
# pymupdf
python3 -c "import fitz; doc = fitz.open('doc.pdf'); print(doc[0].get_text())"

# marker-pdf (better for complex layouts)
marker_single input.pdf output.md
```

---

## 6. PowerPoint

Create, read, edit .pptx decks.

```python
from pptx import Presentation
prs = Presentation()
slide = prs.slides.add_slide(prs.slide_layouts[0])
slide.shapes.title.text = "Hello"
prs.save("output.pptx")
```

---

## 7. Maps (OpenStreetMap)

Geocoding, POIs, routes, timezones.

```bash
# Geocode
curl "https://nominatim.openstreetmap.org/search?q=1600+Amphitheatre+Parkway&format=json"

# Route
curl "https://router.project-osrm.org/route/v1/driving/-122.4,37.8;-122.5,37.7?overview=false"

# Timezone
curl "https://nominatim.openstreetmap.org/reverse?lat=37.77&lon=-122.42&format=json"
```

---

## 8. Teams Meeting Pipeline

Summarize Microsoft Teams meetings via Hermes CLI.

```bash
# Requires MSGRAPH_TENANT_ID, MSGRAPH_CLIENT_ID, MSGRAPH_CLIENT_SECRET
hermes teams-meeting list
hermes teams-meeting summarize --meeting-id ID
hermes teams-meeting pipeline status
hermes teams-meeting pipeline replay --job-id ID
```
