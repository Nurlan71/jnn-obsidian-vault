---
name: creative
description: "Creative content generation: diagrams, ASCII art, video, infographics, web design, sketches, music, animations, generative art."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [creative, design, diagrams, art, music, video, animation, generative]
    related_skills: [architecture-diagram, ascii-art, ascii-video, baoyu-infographic, claude-design, comfyui, design-md, excalidraw, humanizer, manim-video, p5js, popular-web-designs, pretext, sketch, songwriting-and-ai-music, touchdesigner-mcp]
---

# Creative Content Generation

This is the umbrella skill for creative content tools — diagrams, art, music, video, design, and generative content.

---

## Diagrams & Visualization

### Architecture Diagrams
Dark-themed SVG architecture/cloud/infra diagrams as HTML.

### Excalidraw
Hand-drawn style diagrams (architecture, flow, sequence) as Excalidraw JSON.

### Baoyu Infographics
21 layouts × 21 styles for data visualization and infographics.

### design-md
Author/validate/export Google's DESIGN.md token spec files for design systems.

---

## Text & ASCII Art

### ASCII Art
pyfiglet, cowsay, boxes, image-to-ASCII conversion.

### ASCII Video
Convert video/audio to colored ASCII art MP4/GIF.

### Pretext
DOM-free text layout for ASCII art, typographic flow, kinetic typography, text-powered generative art.

### Humanizer
Strip AI-isms from text and add natural voice.

---

## Web Design & Prototyping

### Claude Design
One-off HTML artifacts: landing pages, decks, prototypes.

### Sketch
Throwaway HTML mockups: 2-3 design variants to compare.

### Popular Web Designs
54 real design systems (Stripe, Linear, Vercel) as HTML/CSS reference.

### p5.js
Interactive sketches: generative art, shaders, 3D.

---

## Video & Animation

### Manim Video
3Blue1Brown-style math/algorithm animations using Manim CE.

### ComfyUI
Generate images, video, and audio with ComfyUI workflows (Stable Diffusion, etc.).

---

## Music & Audio

### Songwriting & AI Music
Songwriting craft and Suno AI music prompt engineering.

### TouchDesigner MCP
Control a running TouchDesigner instance for real-time visuals (36 native tools via MCP).

---

## Choosing the Right Tool

| Goal | Skill |
|------|-------|
| Architecture diagram | `architecture-diagram` or `excalidraw` |
| Data visualization | `baoyu-infographic` |
| ASCII art from text | `ascii-art` |
| ASCII art from video | `ascii-video` |
| Landing page mockup | `claude-design` or `sketch` |
| Compare design variants | `sketch` |
| Design system reference | `popular-web-designs` |
| Interactive generative art | `p5js` |
| Math/algorithm animation | `manim-video` |
| Image/video generation | `comfyui` |
| Real-time visuals | `touchdesigner-mcp` |
| Song/music generation | `songwriting-and-ai-music` |
| Text humanization | `humanizer` |
| Design tokens | `design-md` |
| Browser text demos | `pretext` |
