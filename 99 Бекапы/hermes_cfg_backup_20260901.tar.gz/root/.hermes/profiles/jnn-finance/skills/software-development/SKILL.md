---
name: software-development
description: "Software development practices: debugging, TDD, code review, spikes, simplification, Python/Node debugging, skill authoring."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [development, debugging, testing, tdd, code-review, refactor, python, nodejs, skills]
    related_skills: [systematic-debugging, test-driven-development, requesting-code-review, simplify-code, spike, python-debugpy, node-inspect-debugger, hermes-agent-skill-authoring]
---

# Software Development Practices

This is the umbrella skill for software development methodologies and tools. It covers debugging, testing, code review, experimentation, and skill authoring.

---

## 1. Systematic Debugging

**Core principle:** ALWAYS find root cause before attempting fixes. Symptom fixes are failure.

### 4-Phase Process

1. **Understand** — Reproduce the bug, read error messages, check logs, gather context
2. **Isolate** — Narrow to the smallest reproducing case; binary search the change that introduced it
3. **Diagnose** — Form a hypothesis, test it, confirm root cause
4. **Fix** — Address root cause, not symptoms; verify the fix doesn't break anything else

### Anti-Patterns

- Random fixes without understanding
- Quick patches that mask underlying issues
- Fixing symptoms instead of root causes
- Not reproducing before fixing

---

## 2. Test-Driven Development (TDD)

**Core principle:** If you didn't watch the test fail, you don't know if it tests the right thing.

### RED-GREEN-REFACTOR

1. **RED** — Write a failing test that describes the desired behavior
2. **GREEN** — Write the minimal code to make the test pass
3. **REFACTOR** — Clean up the code while keeping tests green

### When to Use

- New features with clear requirements
- Bug fixes (write a test that reproduces the bug first)
- Refactoring (tests ensure behavior is preserved)

---

## 3. Pre-Commit Code Review

**Core principle:** No agent should verify its own work. Fresh context finds what you miss.

### Pipeline

1. **Security scan** — Check for hardcoded secrets, SQL injection, XSS
2. **Quality gates** — Linting, type checking, baseline-aware diff
3. **Independent reviewer** — Spawn a subagent with fresh context to review
4. **Auto-fix loop** — Apply safe fixes automatically, escalate ambiguous ones

---

## 4. Simplify Code (Parallel 3-Agent Cleanup)

**Core principle:** Three narrow reviewers beat one broad reviewer.

Spawn three parallel subagents, each focused on one class of problem:
- **Reuse reviewer** — Finds duplicated logic that should be extracted
- **Quality reviewer** — Finds naming, complexity, and style issues
- **Dead code reviewer** — Finds unused functions, imports, and branches

Aggregate findings and apply the fixes worth applying.

---

## 5. Spike (Throwaway Experiments)

**Core principle:** Spikes are disposable by design. Throw them away once they've paid their debt.

### When to Use

- "Let me try this" / "Is this even possible?"
- Comparing approaches before committing
- Surfacing unknowns that research can't answer
- Quick proof-of-concept before a real build

### When NOT to Use

- When the approach is already clear
- For production code
- When a quick search would answer the question

---

## 6. Python Debugging (pdb + debugpy)

Three tools, picked by situation:

| Tool | When |
|------|------|
| `pdb` | Quick post-mortem, simple scripts |
| `debugpy` | Remote debugging, IDE integration |
| `breakpoint()` | In-code breakpoint for development |

```bash
# Post-mortem
python3 -m pdb script.py

# Remote debugging
python3 -m debugpy --listen 5678 --wait-for-client script.py
```

---

## 7. Node.js Inspect Debugger

Drive Node's built-in V8 inspector programmatically from the terminal.

```bash
# Start with inspector
node --inspect script.js
node --inspect-brk script.js  # Break on first line

# Connect via CLI
node inspect localhost:9229
```

Supports: breakpoints, step in/over/out, call-stack walking, scope dumps, expression evaluation.

---

## 8. Hermes Agent Skill Authoring

### Two Locations

1. **User-local:** `~/.hermes/skills/<category>/<name>/SKILL.md` — personal, created via `skill_manage(action='create')`
2. **In-repo:** `<repo>/.hermes/skills/<name>/SKILL.md` — shared with the project

### SKILL.md Structure

```yaml
---
name: skill-name
description: "What this skill does."
version: 1.0.0
author: Name
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [tag1, tag2]
    related_skills: [other-skill]
---
```

### Best Practices

- Frontmatter is required (name, description, version)
- Use `references/` for detailed docs, `templates/` for starter files, `scripts/` for runnable code
- Keep SKILL.md focused on when to use and how; put deep detail in `references/`
