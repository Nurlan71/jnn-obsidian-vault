---
name: media
description: "Media tools: GIF search, music generation, audio analysis, YouTube transcripts."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [media, gif, music, audio, youtube, video, search]
    related_skills: [gif-search, heartmula, songsee, youtube-content]
---

# Media Tools

This is the umbrella skill for media content tools: GIF search, music generation, audio analysis, and YouTube content extraction.

---

## 1. GIF Search (Tenor)

Search and download GIFs from Tenor.

```bash
# Requires TENOR_API_KEY env var
curl "https://g.tenor.com/v1/search?q=hello&key=$TENOR_API_KEY&limit=10" | jq '.results[].media[].gif.url'

# Download
curl -o hello.gif "$(curl -s "https://g.tenor.com/v1/search?q=hello&key=$TENOR_API_KEY&limit=1" | jq -r '.results[0].media[0].gif.url')"
```

---

## 2. HeartMuLa (Music Generation)

Open-source music generation from lyrics + tags (Apache-2.0, comparable to Suno).

```bash
# Install
pip install heartmula

# Generate from lyrics
heartmula generate --lyrics "Your lyrics here" --tags "pop,upbeat" --output song.wav
```

Supports: multilingual lyrics, multiple genres, full song generation.

---

## 3. Songsee (Audio Analysis)

Audio spectrograms and feature extraction (mel, chroma, MFCC).

```bash
# Install
pip install songsee

# Generate spectrogram
songsee spectrogram audio.wav -o spectrogram.png

# Extract features
songsee features audio.wav --mel --chroma --mfcc
```

---

## 4. YouTube Content

Extract transcripts from YouTube videos and convert to summaries, threads, or blog posts.

```bash
# Install
pip install youtube-transcript-api

# Get transcript
youtube-transcript-api "https://youtube.com/watch?v=VIDEO_ID"

# With Python
from youtube_transcript_api import YouTubeTranscriptApi
transcript = YouTubeTranscriptApi.get_transcript("VIDEO_ID")
text = " ".join([t["text"] for t in transcript])
```

Use the extracted text with the agent's summarization capabilities to create:
- Chapter summaries
- Twitter/X threads
- Blog posts
- Key takeaways
