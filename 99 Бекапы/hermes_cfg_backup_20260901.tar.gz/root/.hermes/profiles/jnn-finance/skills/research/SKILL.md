---
name: research
description: "Research tools: arXiv, blog monitoring, LLM Wiki, Polymarket, paper writing."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [research, arxiv, blogs, wiki, prediction-markets, paper-writing, academic]
    related_skills: [arxiv, blogwatcher, llm-wiki, polymarket, research-paper-writing]
---

# Research Tools

This is the umbrella skill for research and information-gathering tools.

---

## 1. arXiv

Search arXiv papers by keyword, author, category, or ID.

```bash
# Install
pip install arxiv

# Python
import arxiv
results = arxiv.Search(query="cat:cs.LG AND transformer", max_results=10)
for r in results.results():
    print(f"{r.title} ({r.published.year}) - {r.entry_id}")
```

```bash
# curl
curl "https://export.arxiv.org/api/query?search_query=cat:cs.LG&max_results=10"
```

---

## 2. Blogwatcher (RSS/Atom Feed Monitoring)

Monitor blogs and RSS/Atom feeds.

```bash
# Install
cargo install blogwatcher-cli

# Add feeds
blogwatcher-cli add "https://example.com/feed.xml"

# List feeds
blogwatcher-cli list

# Check for new posts
blogwatcher-cli check

# Watch (continuous)
blogwatcher-cli watch
```

---

## 3. LLM Wiki (Karpathy's Interlinked Knowledge Base)

Build and query an interlinked markdown knowledge base.

```bash
# Clone
git clone https://github.com/karpathy/llm-wiki.git

# Build index
python3 build_index.py

# Query
python3 query.py "attention mechanism"
```

The wiki uses markdown files with `[[wiki-links]]` for interlinking. Good for building domain-specific knowledge bases.

---

## 4. Polymarket (Prediction Markets)

Query prediction market data from Polymarket's public REST API (no auth required).

```bash
# List markets
curl "https://gamma-api.polymarket.com/markets?limit=20"

# Get market details
curl "https://gamma-api.polymarket.com/markets/{market_id}"

# Get prices
curl "https://clob.polymarket.com/market/{condition_id}"
```

See `references/api-endpoints.md` in the original skill directory for full endpoint reference.

---

## 5. Research Paper Writing

Write ML papers for NeurIPS/ICML/ICLR/ACL: design → experiment → write → submit.

### Pipeline

1. **Design** — Define hypothesis, methodology, experiments
2. **Implement** — Run experiments, collect results
3. **Analyze** — Statistical analysis, plots, tables
4. **Write** — LaTeX paper following conference format
5. **Submit** — Format check, generate camera-ready

### Key Dependencies

```
semanticscholar, arxiv, habanero, scipy, numpy, matplotlib, SciencePlots
```

### Conference Formats

- **NeurIPS**: 9 pages + references, double-column
- **ICML**: 8 pages + references, double-column
- **ICLR**: 9 pages + references, double-column
- **ACL**: 8 pages + references, double-column
