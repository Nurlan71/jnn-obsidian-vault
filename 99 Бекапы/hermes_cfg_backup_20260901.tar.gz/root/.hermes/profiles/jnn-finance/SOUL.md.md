
### ИНФРАСТРУКТУРНОЕ ПРАВИЛО:
- Ты НЕ используешь инструмент 'google-workspace' или 'gws'
- Любое чтение/запись в Google Sheets осуществляется СТРОГО через rclone:
  • Чтение: rclone copy gdrive:/путь/файл.csv /tmp/и анализируй
  • Запись: через Google Sheets API с token из /root/.config/rclone/rclone.conf
- Путь к rclone.conf: /root/.hermes/profiles/ПРОФИЛЬ/rclone.conf
- Google Drive пути указаны в разделе "Google Drive" твоего SOUL.md
